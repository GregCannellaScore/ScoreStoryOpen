    <!DOCTYPE html>
<html>
<head>
	<meta charset="UTF-8">
	<title>Maintain Dashboard Details</title>
	<link rel="stylesheet" type="text/css" href="Style.css">
	
	
<script type="text/javascript">
function hideshow(){

//if (document.getElementById("ddchart").value == "")
//	document.getElementById("ModChartBtn").style.display="none"
//else
//	document.getElementById("ModChartBtn").style.display="block";

// Check radio values
	
var radios = document.getElementsByName('ddsqltype');

for (var i = 0, length = radios.length; i < length; i++) {
    if (radios[i].checked) {
        // do whatever you want with the checked radio
        //alert(radios[i].value);
        radioValue = radios[i].value;
        // only one radio can be logically checked, don't check the rest
        break;
    }
}
	
if (radioValue === "N")
	document.getElementById("ResultTable").style.display="block"
else
	document.getElementById("ResultTable").style.display="none";

if (radioValue === "C")
	document.getElementById("ShowChart").style.display="table-row"
else
	document.getElementById("ShowChart").style.display="none";
	
}
</script>	
	
	
</head>

<body onload="hideshow()">

<?php
// Process the submitted form
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    
    $ddname = $_GET['DB'];
    $getsub = $_GET['SUB'];
    $ddheading = str_replace("'","''",$_POST['ddheading']);
    $ddsql =  str_replace("'","''",$_POST['ddsql']); 
    $ddsqltype = $_POST['ddsqltype'];
    $ddhtml =  $_POST['ddhtml'];
    $ddprepgm = $_POST['ddprepgm'];
    $ddchart = $_POST['ddchart'];
    $ddredsign = $_POST['ddredsign'];
    $ddredvalue = $_POST['ddredvalue'];
    $ddylwsign = $_POST['ddylwsign'];
    $ddylwvalue = $_POST['ddylwvalue'];
    $ddgrnsign = $_POST['ddgrnsign'];
    $ddgrnvalue = $_POST['ddgrnvalue'];
    
    // Update the record
    $conn = "*LOCAL";
    $i5link = db2_connect($conn, "","");
    
    //       Prepare SQL statement - Insert new record
    
    $sql = "Update jerrymouse.dshdtlm set ddheading= '$ddheading', ddsql='$ddsql', ddsqltype = '$ddsqltype', ddhtml = '$ddhtml' ,
    ddprepgm = '$ddprepgm', ddchart = '$ddchart', ddredsign = '$ddredsign', ddredvalue = $ddredvalue, ddylwsign = '$ddylwsign',
    ddylwvalue = $ddylwvalue, ddgrnsign = '$ddgrnsign', ddgrnvalue = $ddgrnvalue 
    WHERE ddname = '$ddname' and ddsub = '$getsub'";
    echo $sql;
    //      Execute SQL statement
    $stmt = db2_exec($i5link,$sql)
    or die("<p>Failed query:". db2_stmt_error().":".db2_stmt_errormsg()."</p>");
    
    If ($_POST['action'] == 'Modify Chart') {
        header("Location: /jerrymouse/maintdbchart.php?DB=$ddname&CHART=$ddchart");
        exit;
    }
    
    header("Location: /jerrymouse/showdashboard.php?DB=$ddname");
    exit;
    
  
}

?>

	<div class="body-container">
		<img src="/JerryMouse/Images/YourLogo.png" alt="Powered By ScoreStory" height="100" width="200" align="right">
		
		<div class="text-container">	
				
				
				<?php 
				// Set parameters and call generate program
				$ddname = $_GET['DB'];
				$getsub = $_GET['SUB'];
				
				
				// DB2 Version
				$conn = "*LOCAL";
				$i5link = db2_connect($conn, "","");
				/* Construct the SQL statement */
				$sql = "SELECT * FROM JerryMouse.dshdtlm WHERE ddname = '$ddname' and ddsub = '$getsub'";
				
				/* Prepare, bind and execute the DB2 SQL statement */
				$stmt = db2_prepare($i5link,$sql);
				
				$flds = db2_num_fields($stmt);
				
				//Execute statement
				 
				$result = db2_execute($stmt);
				
				if (!$result) {
				    echo 'The db2 execute failed. ';
				    echo 'SQLSTATE value: ' . db2_stmt_error();
				    echo ' Message: ' .   db2_stmt_errormsg();
				    echo '<br>' . $sql;
				}
				else
				{
				    $row = db2_fetch_array($stmt);
				    $ddheading = $row[2];
				    $ddconturl = $row[3];
				    $ddprogram = $row[4];
				    $ddsql = $row[5];
				    $ddsqltype = $row[6];
				    $ddlastrdt = $row[7];
				    $ddlastrtm = $row[8];
				    $ddrfshuom = $row[9];
				    $ddrfshunt = $row[10];
				    $ddludt = $row[11];
				    $ddlutm = $row[12];
				    $ddluus = $row[13];
				    $ddlupg = $row[14];
				    $ddhtml = $row[15];
				    $ddredsign = $row[16];
				    $ddredvalue = $row[17];
				    $ddylwsign = $row[18];
				    $ddylwvalue = $row[19];
				    $ddgrnsign = $row[20];
				    $ddgrnvalue = $row[21];
				    $ddprepgm = $row[22];
				    $ddchart = $row[23];
				    
				    
				    
				}
				//close connection
				db2_close($i5link);
				
				echo "<h1>Maintain Component - $ddheading</h1>";
				?>
				
				
				<form method="post">
				<table class="table-noline">
				<tr>
				<td>
				<table class="table-noline">
				<tr>
				<td>
				<label for="ddheading">Detail Heading</label>
				</td>
				<td>
				<input id="ddheading" name="ddheading" size="50" maxlength="50" value="<?php echo trim($ddheading)?>" />
				</td>
				</tr>
				
				<tr>
				<td>
				<label for="ddsqltype">Component Type</label>
				</td>
				<td>
				<input type="radio" name="ddsqltype" value="T" <?php if ($ddsqltype=='T') {echo 'checked';}?> onChange="hideshow()" >Table<br>
				<input type="radio" name="ddsqltype" value="N" <?php if ($ddsqltype=='N') {echo 'checked';}?> onChange="hideshow()" >Single Number<br>
				<input type="radio" name="ddsqltype" value="C" <?php if ($ddsqltype=='C') {echo 'checked';}?> onChange="hideshow()" >Chart
				</td>
				</tr>
				
				<tr>
				<td>
				<label for="ddsql">Content SQL</label>
				</td>
				<td>
				<textarea rows="7" cols="70" id="ddsql" name="ddsql" maxlength="2000"><?php echo trim($ddsql)?></textarea>
				</td>
				</tr>
				  
	            
				<tr>
				<td>
				<label for="ddhtml">HTML Constant</label>
				</td>
				<td>
				<textarea rows="7" cols="70" id="ddhtml" name="ddhtml" maxlength="500"><?php echo trim($ddhtml)?></textarea>
				</td>
				</tr>
				
				<tr>
				<td>
				<label for="ddprepgm">Pre-Process Program</label>
				</td>
				<td>
				<input id="ddprepgm" name="ddprepgm" maxlength="20" value="<?php echo trim($ddprepgm)?>" />
				</td>
				</tr>
				
				<tr id="ShowChart">
				<td>
				<label for="ddchart">Chart Name</label>
				</td>
				<td>
				<input id="ddchart" name="ddchart" maxlength="20" value="<?php echo trim($ddchart)?>" />
				&nbsp;&nbsp;<input type="submit" name="action" value="Modify Chart" />
				</td>
				</tr>
				
				  
				</table>
				</td>
				</tr>
				<tr>
				<td id="ResultTable">
				<h3>SQL Result Number Coloring</h3> (Only used when an SQL returns a single number.)
				<table class="table-noline" >
				
				<tr>
				<td>
				<label for="ddredsign">If result value is </label>
				<input list="ddredsign" name="ddredsign" maxlength="2" size="4" value="<?php echo trim($ddredsign)?>" />
				<datalist id="ddredsign">
				  <option value=">">
				  <option value="&<;">
				  <option value="=">
				  <option value="<>">
				  <option value=">=">
				  <option value="<=">
				</datalist>
				<input type="number" name="ddredvalue" max="9999999999.99999" size="15" value="<?php echo trim($ddredvalue)?>" />
				, then turn the value red.
				</td>
				</tr>
				
				<tr>
				<td>
				<label for="ddlywsign">If result value is </label>
				<input list="ddylwsign" name="ddylwsign" maxlength="2" size="4" value="<?php echo trim($ddylwsign)?>" />
				<datalist id="ddylwsign">
				  <option value=">">
				  <option value="&<;">
				  <option value="=">
				  <option value="<>">
				  <option value=">=">
				  <option value="<=">
				</datalist>
				<input type="number" name="ddylwvalue" max="9999999999.99999" size="15" value="<?php echo trim($ddylwvalue)?>" />
				, then turn the value yellow.
				</td>
				</tr>
				
				<tr>
				<td>
				<label for="ddgrnsign">If result value is </label>
				<input list="ddgrnsign" name="ddgrnsign" maxlength="2" size="4" value="<?php echo trim($ddgrnsign)?>" />
				<datalist id="ddgrnsign">
				  <option value=">">
				  <option value="&<;">
				  <option value="=">
				  <option value="<>">
				  <option value=">=">
				  <option value="<=">
				</datalist>
				<input type="number" name="ddgrnvalue" max="9999999999.99999" size="15" value="<?php echo trim($ddgrnvalue)?>" />
				, then turn the value green.
				</td>
				</tr>
				
				</table>
				</td>
				</tr>
				<tr>
	            <td>
				<input type="submit" name="action" value="Update" />
				</td>
				</tr>
				</table>
				</form>
						    
                
			
		</div>
		
		<div class="footer">
			Powered by: ScoreStory		
		</div>

	</div>
	
</body>
</html>
