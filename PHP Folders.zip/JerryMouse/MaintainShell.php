    <!DOCTYPE html>
<html>
<head>
	<meta charset="UTF-8">
	<title>Maintain Dashboard Shells</title>
	<link rel="stylesheet" type="text/css" href="Style.css">
	

</head>

<body>

<?php
// Process the submitted form
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    
    $ddHTMLName = $_POST['ddHTMLName'];
    header("Location: MaintainHTMLShell.php?HTMLName=$ddHTMLName");
    
    exit;
    
  
}

?>

	<div class="body-container">
		<img src="/JerryMouse/Images/YourLogo.png" alt="Powered By JerryMouse" height="100" width="200" align="right">
		
		<div class="text-container">	
				
				
								
				
				<h1>Maintain HTML </h1>
				
				
				<form method="post">
				<table class="table-noline">
							
				
				<tr>
				<td>
				<label for="ddHTMLName">HTML Shell Name</label>
				</td>
				<td>
				<input id="ddHTMLName" name="ddHTMLName" size="50" maxlength="50"/>
				</td>
				</tr>
				 		
								
				</table>
				</td>
				</tr>
				<tr>
	            <td>
				<input type="submit" name="action" value="Select for Update" />
				</td>
				</tr>
				</table>
				</form>
						    
                
			
		</div>
		
		<div class="footer">
			Powered by: ScoreStory		
		</div>

	</div>
	
</body>
</html>
