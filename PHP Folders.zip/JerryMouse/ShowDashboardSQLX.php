<?php

function ShowDashboardSQL(&$pdbname, &$pdbdesc, &$pdbparm, &$pdbbody)
{
    $conn_resource = db2_connect("*LOCAL", "", "");
     
    if (!$conn_resource) {
        echo "Connection failed. SQL Err:";
        echo db2_conn_error();
        echo "<br>";
        echo db2_conn_errormsg();
    
        exit();
    }
    
    // echo "Executing  SQL statement: SELECT * FROM magidf.ctm0550w for fetch only"."<br>", "<br>";
    
    /* Construct the SQL statement */
    $User = trim(strtoupper($_SERVER['PHP_AUTH_USER'])) ;
    //echo $User;
    $sql = "SELECT DBTITLE, qgpl.getdashboard2(dbname,char('$User'),char('$pdbparm')) FROM magidf.dshhdrm where dbname = '" . $pdbname . "' for fetch only";
    //  " . {$_SERVER['PHP_AUTH_USER']} . "
    //echo $sql;
    /* Prepare, bind and execute the DB2 SQL statement */
    $stmt= db2_prepare($conn_resource, $sql);
    
    $flds = db2_num_fields($stmt);
    
    //Execute statement
     
    $result = db2_execute($stmt);
    
    if (!$result) {
        echo 'The db2 execute failed. ';
        echo 'SQLSTATE value: ' . db2_stmt_error();
        echo ' Message: ' .   db2_stmt_errormsg();
        echo '<br>' . $sql;
    }
    else
    {
        
        while ($row = db2_fetch_array($stmt))
        {
            
            //echo $row[0];
            //echo $row[1];
            $pdbdesc = $row[0];
            $file = rtrim($row[1]);
            $DashBoardFound = 'Y';
            //$file = '/www/zendsvr6/htdocs/Charts/REACOTTSLS001.html' or die('Could not open file 1! ');
            
            // open file
            
            $fh = fopen($file, 'r') or die('Could not open file!');
            
            // read file contents
            
            $pdbbody = fread($fh, filesize($file)) or die('Could not read file!');
            
            // close file
            
            fclose($fh);
        }
        If ($DashBoardFound <> 'Y') {
            Echo 'Dashboard not found.  Check the name in the DB parameter in the URL.
                <a href="NewDashboardHeader.php?DB=' . $pdbname . '">Click here to create a new dashboard.</a>';
        }
        
    }
    
    
    
}
?>