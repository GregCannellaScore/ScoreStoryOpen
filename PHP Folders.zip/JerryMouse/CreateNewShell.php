<?php
// HTML Shell Upload screen
// include( 'function.php');

// Get incomming parms
$EmailName = $_POST['EmailName'];
$EmailBody = $_POST['EmailBody'];
$SubValue1 = $_POST['SubValue1'];
$SubValue2 = $_POST['SubValue2'];
$SubValue3 = $_POST['SubValue3'];
$SubValue4 = $_POST['SubValue4'];
$SubValue5 = $_POST['SubValue5'];
$SubValue6 = $_POST['SubValue6'];
$SubValue7 = $_POST['SubValue7'];
$SubValue8 = $_POST['SubValue8'];
$SubValue9 = $_POST['SubValue9'];
$SubValue10 = $_POST['SubValue10'];

    //       Write record to database
    $conn = "*LOCAL";
    $i5link = db2_connect($conn, "","");
    if($i5link) echo "<p>Connected to IBM i</p>";
        else echo "<p>Connection Failed</p>".db2_stmt_error().":".db2_stmt_errormsg()."</p>";
    // Escape all sinsle quotes
    $EmailBody = str_replace("'", "''", $EmailBody);
    //       Prepare SQL statement - Insert new record
    $sql = "Insert into jerrymouse.HTMLBDM (HXBODYNAME,HXBODY,HXSUB1,HXSUB2,HXSUB3,HXSUB4,HXSUB5,HXSUB6,HXSUB7,HXSUB8,HXSUB9,HXSUB10) 
    values('$EmailName','$EmailBody','$SubValue1','$SubValue2','$SubValue3','$SubValue4','$SubValue5','$SubValue6','$SubValue7','$SubValue8','$SubValue9','$SubValue10')";
    echo $sql;
    //      Execute SQL statement 
    $stmt = db2_exec($i5link,$sql)
    or die("<p>Failed query:". db2_stmt_error().":".db2_stmt_errormsg()."</p>");
    // Redirect to success screen
    header('Location: CreateNewShellSuccess.html');
    
    

?>