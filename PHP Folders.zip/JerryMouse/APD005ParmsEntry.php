<!DOCTYPE html>
<html>
<head>
	<meta charset="UTF-8">
	<title>Show Dashboard</title>
	<link rel="stylesheet" type="text/css" href="/Magid.css">
	
	
</head>

<body>

<?php
// Process the submitted form
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    
    $dbname = $_GET['DB'];
    $dbdata1 = $_POST['dbdata1'];
    $dbdata2 = $_POST['dbdata2'];
    
    $dbdata3 = '1' . substr($dbdata1, 2,2) . substr($dbdata1, 5,2) . substr($dbdata1, 8,2);
    $dbdata4 = '1' . substr($dbdata2, 2,2) . substr($dbdata2, 5,2) . substr($dbdata2, 8,2);
    
    $url ='Location: /dashboards/showdashboard.php?DB=' . trim($dbname) . '&pmfromdate=' .
          trim($dbdata3) . '&pmtodate=' . trim($dbdata4);
    header("$url");
    exit;
    
  
}

?>

	<div class="body-container">
		<img src="/Images/Magid_with_tagline_PMS485-black_jpg.jpg" alt="Magid - Safety at work" height="92" width="152" align="right">
		
		<div class="text-container">	
				
				
						
				
				<form method="post">
				<table class="table-noline">
								
				<tr>
				<td>
				<label for="dbdata1">Begin Date(CCYY-MM-DD)</label>
				</td>
				<td>
				<input type="date" name="dbdata1" required />
				</td>
								</tr>
				
				<tr>
				<td>
				<label for="dbdata2">End Date(CCYY-MM-DD)</label>
				</td>
				<td>
				<input type="date" name="dbdata2" required />
				</td>
								</tr>
				
	            <tr>
	            <td>
				<input type="submit" value="Update" />
				</td>
				</tr>  
				  </table>
				</form>
						    
                
			
		</div>
		
		<div class="footer">
			2015 Magid Glove and Safety Mfg, LLC		
		</div>

	</div>
	
</body>
</html>