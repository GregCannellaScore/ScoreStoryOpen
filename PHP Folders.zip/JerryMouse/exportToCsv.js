function exportTableToCSV(tablename, filename) {
    var csv = [];
    var rows = document.querySelector(tablename).querySelectorAll("table tr");
    var dbl = '\"';  
    var comma = ',';
    
    for (var i = 0; i < rows.length; i++) {
        var row = [], cols = rows[i].querySelectorAll("table td, th");
        
        for (var j = 0; j < cols.length; j++) {
        
            var temp = (cols[j].innerText) ;
            var temp1 = temp.replace(/"/g," ");
            var txt1 = dbl.concat(temp1,dbl);
            row.push(txt1);
           // row.push(cols[j].innerText);
            
        }
        csv.push(row.join(","));        
    }

    // Download CSV file
    downloadCSV(csv.join("\n"), filename);
}