<!DOCTYPE html>
<?php 
	if (isset($_GET['DB'])) {
        $dbname       = $_GET['DB'];
	}
	
	// $dbparm = str_replace("'","''",var_export($_GET, true));
	if (isset($_GET['pm1'])) {
	    $parm1     = $_GET['pm1'];
	}
	else {
	    $parm1 = 'xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx';
	}
	
	if (isset($_GET['pm2'])) {
	    $parm2     = $_GET['pm2'];
	}
	else {
	    $parm2 = 'xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx';
	}
	
	if (isset($_GET['pm3'])) {
	    $parm3     = $_GET['pm3'];
	}
	else {
	    $parm3 = 'xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx';
	}
	
	if (isset($_GET['pm4'])) {
	    $parm4     = $_GET['pm4'];
	}
	else {
	    $parm4 = 'xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx';
	}
	
	if (isset($_GET['pm5'])) {
	    $parm5     = $_GET['pm5'];
	}
	else {
	    $parm5 = 'xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx';
	}
	// Build Parms
	
	
	$dbparm = str_pad($parm1, 40," ", STR_PAD_RIGHT) . str_pad($parm2, 40," ", STR_PAD_RIGHT) .
	          str_pad($parm3, 40," ", STR_PAD_RIGHT) . str_pad($parm4, 40," ", STR_PAD_RIGHT) .
	          str_pad($parm5, 40," ", STR_PAD_RIGHT)  ;
	          
	// DB2 Version
	$conn = "*LOCAL";
	$i5link = db2_connect($conn, "","");
	/* Construct the SQL statement */
	$sql = "SELECT * FROM jerrymouse.dshhdrm where dbname = '$dbname'";
				
	/* Prepare, bind and execute the DB2 SQL statement */
	$stmt = db2_prepare($i5link,$sql);
				
	$flds = db2_num_fields($stmt);
				
	//Execute statement
				 
	$result = db2_execute($stmt);
				
	if (!$result) {
	    echo 'The db2 execute failed. ';
	    echo 'SQLSTATE value: ' . db2_stmt_error();
	    echo ' Message: ' .   db2_stmt_errormsg();
	    echo '<br>' . $sql;
		}
	else
		{
	    $row = db2_fetch_array($stmt);
	    $stylesheet = $row[8];
	    $sec = $row[9];
	    $page = $row[10];
	    $logo = $row[11];
		}
		
	//if no style sheet default to Style.css
	if (empty(trim($stylesheet))) {
		$stylesheet = "Style.css";	
	}
						
	//if seconds is 0 replace with blanks	
	if (empty($sec)) {
        $sec = " ";
	}
	
	//if no page default to url
	if (empty(trim($page))) {
		$page = $_SERVER['REQUEST_URI'];	
	}
	
	//if no logo and not *NONE default to Magid Logo
	if (empty(trim($logo)) and trim($logo)<>'*NONE') {
	    $logo = '<img src="/JerryMouse/Images/YourLogo.png" alt="Powered By ScoreStory" height="100" width="200" align="right">';
	}
	if (trim($logo)=='*NONE') {
	    $logo ='';
	}
	
	//close connection
	db2_close($i5link);			
?>
<html>
<head>
	<meta charset="UTF-8">
	<title>Show Dashboard</title>
	<link rel="stylesheet" type="text/css" href="<?php echo trim($stylesheet)?>">
	<meta http-equiv="refresh" content="<?php echo trim($sec)?>; URL=<?php echo trim($page)?>">
	<script src="sorttable.js"></script>
	<script src="download.js"></script>
	<script src="exportToCsv.js"></script>
	
</head>

<body>
	<div class="body-container">
		<?php echo trim($logo)?>
		
		<div class="text-container">	
				
				<?php
				
				include('ShowDashboardSQL.php');
				
				// Set parameters and call generate program
				$dbname = $_GET['DB'];
				
				ShowDashboardSQL($dbname, $dbdescription, $dbparm, $dbbody);
				// $dbdescription = Test;
				Echo "<h1>";
	            Echo $dbdescription;
	            Echo "</h1>";
	            Echo '  <a href="/jerrymouse/maintdbhead.php?DB='.$dbname.'">
				    <img src="Images/maintenance.jpeg" alt="Maintain Header" style="width:30px;height:30px;border:0;">
				    </a>';

		        Echo "<p>";
		        Echo $dbbody;
		        Echo "</p>";
		        
		        
		    
                ?> 
			
			
		</div>
		
		<div class="footer">
			Powered by: ScoreStory		
		</div>

	</div>
	
</body>
</html>
