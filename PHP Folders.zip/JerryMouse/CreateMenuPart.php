<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Create New Menu Part</title>
<link rel="stylesheet" type="text/css" href="Style.css">



<?php
// Process the submitted form
if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    $dbname = $_POST['dbName'];
    $userdbname = "USER" . trim($dbname);
    
    // Create the record
    $conn = "*LOCAL";
    $i5link = db2_connect($conn, "", "");
    
    $sql = "Select * from jerrymouse.dshdtlm where ddname='$userdbname' and ddsub='%SUBCELL1'";
    //echo $sql;
    /* Prepare, bind and execute the DB2 SQL statement */
    $stmt = db2_prepare($i5link,$sql);
    
    $flds = db2_num_fields($stmt);
    
    //Execute statement
    	
    $result = db2_execute($stmt);
    //echo $result;
    if ($result) {
       $row = db2_fetch_array($stmt);
         $testdb = $row[0];
    }
    //echo "<br />" . $testdb . "<br />" . $userdbname;
    if (trim($testdb) <> $userdbname) {
    
    // Prepare SQL statement - Insert new record
    
    $sql = "Insert into jerrymouse.dshdtlm (ddname, ddsub, ddheading, ddconturl, ddprogram, ddsql, ddsqltype, ddlastrdt, ddlastrtm, ddrfshuom, ddrfshunt, ddludt, 
        ddlutm, ddluus, ddlupg, ddhtml, ddredsign, ddredvalue, ddylwsign, ddylwvalue, ddgrnsign, ddgrnvalue, ddprepgm, ddchart, ddjustval) 
        values(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";
    $parms = array($userdbname,'%SUBCELL1', ' ', ' ', ' ', ' ', ' ',0,0, ' ',0,0,0, ' ', ' ', ' ', ' ',0, ' ',0, ' ',0, ' ', ' ', ' ');
    // echo $sql;
    // Execute SQL statement
    $stmt2 = db2_prepare($i5link, $sql);
    $result2 = db2_execute($stmt2, $parms) or die("<p>Failed query:" . db2_stmt_error() . ":" . db2_stmt_errormsg() . "</p>");
    
    
    
    header("Location: MaintDBDetail.php?DB=$userdbname&SUB=%SUBCELL1");
    exit();
    }
    else
    {
        $message = "Can not create the menu part.  The menu part already exists.";
        
    }
}
else
{
    $message = "";
    $dbname = "";
}
?>

</head>

<body>
       <div class="body-container">

		<div class="text-container">
        	<h1>Create New Menu Part</h1>
			<br>

			<form method="post" action="">

				<table>
					<tr>
						<td>Enter the name of your new menu part:</td>
						<td><input id="dbName" name="dbName" size="50" value="<?php echo trim($dbname) ?>"/></td>
					</tr>
					<tr>
					    <td><?php echo$message?></td>
					</tr>
				</table>	
					<input type="submit" value="Continue" />
				
			</form>
			<br>
                           
                                                
        </div>
        
        <div class="footer">
			Powered by: ScoreStory		
		</div>
        
	</div>

</body>
</html>
