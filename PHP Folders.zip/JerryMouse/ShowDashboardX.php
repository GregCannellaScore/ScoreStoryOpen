<!DOCTYPE html>
<?php 
	$dbname       = $_GET['DB'];
	// $dbparm = str_replace("'","''",var_export($_GET, true));
	$parmCust     = $_GET['CUST'];
	$parmVendor   = $_GET['VENDOR'];
	$parmStyle    = $_GET['STYLE'];
	$parmStyle10  = $_GET['STYLE10'];
	$parmCorp     = $_GET['CORP'];
	$parmCategory = $_GET['CATEGORY'];
	$parmSls      = $_GET['SLS'];
	$parmBuyer    = $_GET['BUYER'];
	$parmRegion   = $_GET['REGION'];
	$parmFromDate = $_GET['FROMDATE'];
	$parmToDate   = $_GET['TODATE'];
	$parmLane     = $_GET['LANE'];
	$parmStatus   = $_GET['STATUS'];
	// Build Parms
	//$dbparm = $parmCust + $parmVendor + $parmStyle + $parmStyle10 + $parmCorp + 
	//           $parmCategory + $parmSls + $parmBuyer + $parmRegion;
	
	If ($parmStyle == '') {
	    $parmStyle = 'xxxxxxxxxxxxxx';
	}
	
	If ($parmStyle10 == '') {
	    $parmStyle10 = 'xxxxxxxxxx';
	}
	
    If ($parmCategory == '') {
	    $parmCategory = 'xxxxxxxxxx';
	}
	
	If ($parmRegion == '') {
	    $parmRegion = 'x';
	}
	
	If ($parmLane == '') {
	    $parmLane = 'xxx';
	}
	
	If ($parmStatus == '') {
	    $parmStatus = 'x';
	}
	
	$dbparm = str_pad($parmCust, 7,"0", STR_PAD_LEFT) . str_pad($parmVendor, 5,"0", STR_PAD_LEFT) .
	          str_pad($parmStyle, 14, " ", STR_PAD_RIGHT) .str_pad($parmStyle10, 10," ", STR_PAD_RIGHT) .
	          str_pad($parmCorp, 5,"0", STR_PAD_LEFT) . str_pad($parmCategory, 10," ", STR_PAD_RIGHT) . 
	          str_pad($parmSls, 3,"0", STR_PAD_LEFT) . str_pad($parmBuyer, 5,"0", STR_PAD_LEFT) .
	          str_pad($parmRegion, 1," ", STR_PAD_LEFT) . str_pad($parmFromDate, 7,"0", STR_PAD_LEFT) .
	          str_pad($parmToDate, 7,"0", STR_PAD_LEFT) . str_pad($parmLane, 3,"0", STR_PAD_RIGHT) .
	          str_pad($parmStatus, 1,"0", STR_PAD_RIGHT);
	          
	// DB2 Version
	$conn = "*LOCAL";
	$i5link = db2_connect($conn, "","");
	/* Construct the SQL statement */
	$sql = "SELECT * FROM magidf.dshhdrm where dbname = '$dbname'";
				
	/* Prepare, bind and execute the DB2 SQL statement */
	$stmt = db2_prepare($i5link,$sql);
				
	$flds = db2_num_fields($stmt);
				
	//Execute statement
				 
	$result = db2_execute($stmt);
				
	if (!$result) {
	    echo 'The db2 execute failed. ';
	    echo 'SQLSTATE value: ' . db2_stmt_error();
	    echo ' Message: ' .   db2_stmt_errormsg();
	    echo '<br>' . $sql;
		}
	else
		{
	    $row = db2_fetch_array($stmt);
	    $stylesheet = $row[8];
	    $sec = $row[9];
	    $page = $row[10];
	    $logo = $row[11];
		}
		
	//if no style sheet default to magid.css
	if (empty(trim($stylesheet))) {
		$stylesheet = "/magid.css";	
	}
						
	//if seconds is 0 replace with blanks	
	if (empty($sec)) {
        $sec = " ";
	}
	
	//if no page default to url
	if (empty(trim($page))) {
		$page = $_SERVER['REQUEST_URI'];	
	}
	
	//if no logo and not *NONE default to Magid Logo
	if (empty(trim($logo)) and trim($logo)<>'*NONE') {
	    $logo = '<img src="/Images/Magid_with_tagline_PMS485-black_jpg.jpg" alt="Magid - Safety at work" height="92" width="152" align="right">';
	}
	if (trim($logo)=='*NONE') {
	    $logo ='';
	}
	
	//close connection
	db2_close($conn);			
?>
<html>
<head>
	<meta charset="UTF-8">
	<title>Show Dashboard</title>
	<link rel="stylesheet" type="text/css" href="<?php echo trim($stylesheet)?>">
	<meta http-equiv="refresh" content="<?php echo trim($sec)?>; URL=<?php echo trim($page)?>">
	<script src="sorttable.js"></script>
	
</head>

<body>
	<div class="body-container">
		<?php echo trim($logo)?>
		
		<div class="text-container">	
				
				<?php
				
				include('ShowDashboardSQL.php');
				
				// Set parameters and call generate program
				$dbname = $_GET['DB'];
				
				ShowDashboardSQL($dbname, $dbdescription, $dbparm, $dbbody);
				// $dbdescription = Test;
				Echo "<h1>";
	            Echo $dbdescription;
	            Echo "</h1>";
	            Echo '  <a href="/dashboards/maintdbhead.php?DB='.$dbname.'">
				    <img src="/Images/maintenance.jpeg" alt="Maintain Header" style="width:30px;height:30px;border:0;">
				    </a>';

		        Echo "<p>";
		        Echo $dbbody;
		        Echo "</p>";
		        
		        
		    
                ?> 
			
			
		</div>
		
		<div class="footer">
			Powered by: ScoreStory		
		</div>

	</div>

</body>
</html>
