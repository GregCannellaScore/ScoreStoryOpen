<HTML>
<BODY>
<?php
function showTableWithHeader( $column_names, $column_values)
{

	echo "<table  border=1>";
	/*table header */
    echo "<tr>"; 
	foreach($column_names as $name){
		echo "<td>$name</td>";
      }
    echo "</tr>";

     /*fill table by rows*/      
	foreach($column_values as $key => $element )
	{
		echo "<tr><td>$key</td>";		 
		foreach($element as $value){
			echo "<td>$value</td>";	
            }
      echo "</tr>";
      }
      
	echo "</table>";
}

function showTable( $out)
{

	echo "<table  border=1>";
	echo "<tr><td>Parmeter Name</td> <td>Parameter Value</td></tr>";

	foreach($out as $key=>$value){
		echo "<tr><td>$key</td> <td>$value</td></tr>";
	}
	echo "</table>";
	
}
?>
</BODY>
</HTML>