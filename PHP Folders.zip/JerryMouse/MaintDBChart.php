<!DOCTYPE html>
<html>
<head>
	<meta charset="UTF-8">
	<title>Maintain Dashboard Chart</title>
	<link rel="stylesheet" type="text/css" href="/style.css">
	
	
</head>

<body>

<?php
// Process the submitted form
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    
    $ddname = $_GET['DB'];
    $getchart = $_GET['CHART'];
    $dctitle = $_POST['dctitle'];
    $dcsql =  str_replace("'","''",$_POST['dcsql']); 
    $dctype = $_POST['dctype'];
    $dcpackage =  $_POST['dcpackage'];
    $dcwidth = $_POST['dcwidth'];
    $dcheight = $_POST['dcheight'];
    $dcprogram = $_POST['dcprogram'];
    $dchtml = $_POST['dchtml'];
    $dcvaxis = str_replace("'","''",$_POST['dcvaxis']);
    $dchaxis = str_replace("'","''",$_POST['dchaxis']);
    
    if ($dcwidth === '') $dcwidth = 0;
    if ($dcheight === '') $dcheight = 0;
    
    // Update the record
    $conn = "*LOCAL";
    $i5link = db2_connect($conn, "","");
    
    //       Prepare SQL statement - Insert new record
    
    $sql = "Insert into jerrymouse.dshchtm (dcchart,dctitle,dctype,dcpackage,dcwidth,dcheight,dcprogram,
    dcsql,dclstctdt,dclstcttm,dcrfshuom,dcrfshunt,dcludt,dclutm,dcluus,dclupg,dchtml,dcvaxis,dchaxis) 
    values('$getchart','','','',0,0,'','',0,0,'',0,0,0,'','','','','')";
    $stmt = db2_exec($i5link,$sql);
        
    $sql = "Update jerrymouse.dshchtm set dctitle= '$dctitle', dctype='$dctype', dcpackage = '$dcpackage', dcwidth = $dcwidth ,
    dcheight = $dcheight, dcprogram = '$dcprogram', dcsql = '$dcsql', dchtml = '$dchtml', dcvaxis = '$dcvaxis', dchaxis = '$dchaxis'
    WHERE dcchart = '$getchart'";
    echo $sql;
    //      Execute SQL statement
    $stmt = db2_exec($i5link,$sql)
    or die("<p>Failed query:". db2_stmt_error().":".db2_stmt_errormsg()."</p>");
    
    header("Location: /jerrymouse/showdashboard.php?DB=$ddname");
    exit;
    
  
}

?>

	<div class="body-container">
		<img src="/Images/YourLogo.Png" alt="Powered by: ScoreStory" height="100" width="200" align="right">
		
		<div class="text-container">	
				
				
				<?php 
				// Set parameters and call generate program
				$ddname = $_GET['DB'];
				$getchart = $_GET['CHART'];
				echo "<h1>Maintain Dashboard Chart - $getchart</h1>";
				
				// DB2 Version
				$conn = "*LOCAL";
				$i5link = db2_connect($conn, "","");
				/* Construct the SQL statement */
				$sql = "SELECT * FROM jerrymouse.dshchtm WHERE dcchart = '$getchart'";
				
				/* Prepare, bind and execute the DB2 SQL statement */
				$stmt = db2_prepare($i5link,$sql);
				
				$flds = db2_num_fields($stmt);
				
				//Execute statement
				 
				$result = db2_execute($stmt);
				
				if (!$result) {
				    echo 'The db2 execute failed. ';
				    echo 'SQLSTATE value: ' . db2_stmt_error();
				    echo ' Message: ' .   db2_stmt_errormsg();
				    echo '<br>' . $sql;
				}
				else
				{
				    $row = db2_fetch_array($stmt);
				    $dctitle = $row[1];
				    $dctype = $row[2];
				    $dcpackage = $row[3];
				    $dcwidth = $row[4];
				    $dcheight = $row[5];
				    $dcprogram = $row[6];
				    $dcsql = $row[7];
				    $dclstctdt = $row[8];
				    $dclstcttm = $row[9];
				    $dcrfshuom = $row[10];
				    $dcrfshunt = $row[11];
				    $dcludt = $row[12];
				    $dclutm = $row[13];
				    $dcluus = $row[14];
				    $dclupg = $row[15];
				    $dchtml = $row[16];
				    $dcvaxis = $row[17];
				    $dchaxis = $row[18];
				    
				    
				    
				}
				
				?>
				
				
				<form method="post">
				<table class="table-noline">
				
				<tr>
				<td>
				<label for="dctitle">Chart Title</label>
				</td>
				<td>
				<input id="dctitle" name="dctitle" size="50" maxlength="50" value="<?php echo trim($dctitle)?>" />
				</td>
				</tr>
				
				<tr>
				<td>
				<label for="dctype">Chart Type</label>
				</td>
				<td>
				<input list="dctype" name="dctype" size="30" maxlength="30" value="<?php echo trim($dctype)?>" />
				<datalist id="dctype">
				  <option value="AreaChart">
				  <option value="BarChart">
				  <option value="BubbleChart">
				  <option value="CandlestickChart">
				  <option value="ComboChart">
				  <option value="LineChart">
				  <option value="ScatterChart">
				  <option value="SteppedAreaChart">
				</datalist>
				</td>
				</tr>
				
				<tr>
				<td>
				<label for="dcpackage">Chart Package</label>
				</td>
				<td>
				<input list="dcpackage" name="dcpackage" size="30" maxlength="30" value="<?php echo trim($dcpackage)?>" />
				<datalist id="dcpackage">
				  <option value="corechart">
				</datalist>
				</td>
				</tr>
				
				<tr>
				<td>
				<label for="dcwidth">Chart Width</label>
				</td>
				<td>
				<input type="number" name="dcwidth" size="5" min="50" max="1500" value="<?php echo trim($dcwidth)?>" />
				</td>
				</tr>
				
				<tr>
				<td>
				<label for="dcheight">Chart Height</label>
				</td>
				<td>
				<input type="number" name="dcheight" size="5" min="50" max="1500" value="<?php echo trim($dcheight)?>" />
				</td>
				</tr>
				
				<tr>
				<td>
				<label for="dcprogram">Pre-process Program</label>
				</td>
				<td>
				<input id="dcprogram" name="dcprogram" size="50" maxlength="30" value="<?php echo trim($dcprogram)?>" />
				</td>
				</tr>
				
				
				<tr>
				<td>
				<label for="dcsql">Content SQL</label>
				</td>
				<td>
				<textarea rows="7" cols="70" id="dcsql" name="dcsql" maxlength="2000"><?php echo trim($dcsql)?></textarea>
				</td>
				</tr>
				
				<tr>
				<td>
				<label for="dchtml">HTML Body</label>
				</td>
				<td>
				<input id="dchtml" name="dchtml" size="50" maxlength="50" value="<?php echo trim($dchtml)?>" />
				</td>
				</tr>
				  
	            <tr>
				<td>
				<label for="dcvaxis">Vertical Axis</label>
				</td>
				<td>
				<textarea rows="7" cols="70" id="dcvaxis" name="dcvaxis" maxlength="300"><?php echo trim($dcvaxis)?></textarea>
				</td>
				</tr>
				  
	            <tr>
				<td>
				<label for="dchaxis">Horizontal Axis</label>
				</td>
				<td>
				<textarea rows="7" cols="70" id="dchaxis" name="dchaxis" maxlength="300"><?php echo trim($dchaxis)?></textarea>
				</td>
				</tr>
				
				<tr>
	            <td>
				<input type="submit" value="Update" />
				</td>
				</tr>  
				  
				</table>
				</form>
						    
                
			
		</div>
		
		<div class="footer">
			Powered by: ScoreStory	
		</div>

	</div>
	
</body>
</html>
