<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Create a New Dashboard</title>
<link rel="stylesheet" type="text/css" href="style.css">


</head>

<body>

<?php
// Process the submitted form
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    
    $dbname = $_GET['DB'];
    $dbtitle = $_POST['dbtitle'];
    $dblayout = $_POST['dblayout'];
    $dbstylsht = $_POST['dbstylsht'];
    $dbrfsec = $_POST['dbrfsec'];
    $dbrfurl = $_POST['dbrfurl'];
    $dblogo = $_POST['dblogo'];
    
    // Create the record
    $conn = "*LOCAL";
    $i5link = db2_connect($conn, "", "");
    
    // Prepare SQL statement - Insert new record
    
    $sql = "Insert into jerrymouse.dshhdrm (dbname, dbtitle, dblayout, db#subs, dbludt, dblutm, dbluus, dblupg, dbstylsht, dbrfsec, dbrfurl, dblogo) 
    values('$dbname','$dbtitle','$dblayout',0,0,0,' ',' ','$dbstylsht', '$dbrfsec', '$dbrfurl', '$dblogo')";
    // echo $sql;
    // Execute SQL statement
    $stmt = db2_exec($i5link, $sql) or die("<p>Failed query:" . db2_stmt_error() . ":" . db2_stmt_errormsg() . "</p>");
    
    // Set security all access
    $sql = "Insert into jerrymouse.dshsecm (dsname, dsuser)
    values('$dbname','*ALL')";
    // echo $sql;
    // Execute SQL statement
    $stmt = db2_exec($i5link, $sql) or die("<p>Failed query:" . db2_stmt_error() . ":" . db2_stmt_errormsg() . "</p>");
    
    // Check for detail records that need to be created
    include_once 'authorization.php';
    include_once 'ToolkitService.php';
    include_once 'helpshow.php';
    
    $extension='ibm_db2';
    try {
        $ToolkitServiceObj = ToolkitService::getInstance($db, $user, $pass, $extension);
    }
    
    catch (Exception $e)
    {
        echo  $e->getMessage(), "\n";
        $dbbody = $e;
        exit();
    }
    $ToolkitServiceObj->setToolkitServiceParams(array('InternalKey'=>"/tmp/$user"));
    
    $param[] = $ToolkitServiceObj->AddParameterChar('both', 128,'DashBoardName', 'DBname', $dbname);
    $param[] = $ToolkitServiceObj->AddParameterChar('both', 50,'DashBoardDesc', 'DBDesc', $dblayout);
    
    $result = $ToolkitServiceObj->PgmCall("DSH0200C", "JERRYMOUSE", $param, null, null);
    
    
    
    header("Location: showdashboard.php?DB=$dbname");
    exit();
}

if (isset($dbrfsec) === false) {
    $dbrfsec = 0;
}

?>
	<div class="body-container">
	    <img src="/JerryMouse/Images/YourLogo.png" alt="Powered By JerryMouse" height="100" width="200" align="right">
		
		<div class="text-container">

			<h1>Create a New Dashboard - <?php echo $_GET['DB']?></h1>

			<form method="post">
				<table class="table-noline">
					<tr>
						<td><label for="dbtitle">Dashboard Title</label></td>
						<td><input id="dbtitle" name="dbtitle" /></td>
					</tr>

					<tr>
						<td><label for="dblayout">Dashboard Layout</label></td>
						<td><input type="text" list="dblayoutlist" name="dblayout"> <datalist
								id="dblayoutlist">
								<option value="OneCol">
								
								
								<option value="DBFBLOOK">
								
								
								<option value="2X2">
								
								
								<option value="3X3">
								
								
								<option value="4X4">
							
							</datalist></td>
					</tr>
					
					<tr>
				       	<td>
				       	<label for="dbstlsht">Dashboard Style Sheet</label>
						</td>
						<td>
						<input id="dbstylsht" name="dbstylsht" value="<?php if (isset($dbstylsht)) echo $dbstylsht;?>" />
						</td>
					</tr>
				
					<tr>
						<td>
						<label for="dbrfsec">Dashboard Refresh Rate(sec)</label>
						</td>
						<td>
						<input id="dbrfsec" name="dbrfsec" value="<?php if (isset($dbrfsec)) echo $dbrfsec;?>" />
						</td>
					</tr> 
				
					<tr>
						<td>
						<label for="dbrfurl">Dashboard Refresh URL</label>
						</td>
						<td>
						<input id="dbrfurl" name="dbrfurl" value="<?php if (isset($dbrfurl)) echo $dbrfurl;?>" />
						</td>
					</tr>
					
					<tr>
						<td>
						<label for="dblogo">Dashboard logo URL</label>
						</td>
						<td>
						<input id="dblogo" name="dblogo" value="<?php if (isset($dblogo)) echo $dblogo;?>" />
						</td>
					</tr>
					
					<tr>
						<td><input type="submit" value="Create" /></td>
					</tr> 
					
				</table>
			</form>



		</div>

		<div class="footer">Powered by: ScoreStory</div>

	</div>


</body>
</html>
