<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Dashboard Security</title>
<link rel="stylesheet" type="text/css" href="Style.css">


</head>

<body>
<?php
$dsname = $_GET['DB'];
//$user = trim(strtoupper($_SERVER['PHP_AUTH_USER']));
//if ($user<>'GREGC') {
//    echo "You dont have access to this screen.";
//    exit;
//}
?>
       <div class="body-container">

		<div class="text-container">
			<h1>Dashboard Security</h1>
			<br>
            <a href="AddSecurity.php?DB=<?php echo trim($dsname) ?>" class="button">Add Security Access</a>
			<br><br>
                     <?php
                    // DB2 Version
                    $conn = "*LOCAL";
                    $i5link = db2_connect($conn, "", "");
                    /* Construct the SQL statement */
                    $sql = "SELECT * FROM jerrymouse.dshsecm where dsname = '$dsname' order by dsname, dsuser";
                    // echo $sql;
                    /* Prepare, bind and execute the DB2 SQL statement */
                    $stmt = db2_prepare($i5link, $sql);
                    
                    $flds = db2_num_fields($stmt);
                    
                    // Execute statement
                    
                    $result = db2_execute($stmt);
                    
                    if (! $result) {
                        echo 'The db2 execute failed. ';
                        echo 'SQLSTATE value: ' . db2_stmt_error();
                        echo ' Message: ' . db2_stmt_errormsg();
                        echo '<br>' . $sql;
                    } else {
                        echo '<table class="table-all-lines"><tr><th>Actions</th><th>Dashboard Name</th><th>User/Group</th></tr>';
                        do {
                            $row = db2_fetch_array($stmt);
                            if ($row != null) {
                                $dsname = $row[0];
                                $dsuser = $row[1];
                                
                                echo "<tr><td><a href=" . '"' . "http:DBSecDelete.php?DB=$dsname&USER=$dsuser" . '"' . " class=" . '"button"' . ">Delete</a>
                                      <td>$dsname</td><td>$dsuser</td></tr>";
                                
                            }
                        } while ($row != null);
                        echo "</table>";
                    }
                    // close connection
                    db2_close($i5link);
                    
                    ?>
                           
                                                
              </div>

	</div>

</body>
</html>