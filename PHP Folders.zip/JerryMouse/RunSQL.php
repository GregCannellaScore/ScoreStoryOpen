<!DOCTYPE html>
<html>
<head>
	<meta charset="UTF-8">
	<title>Run Interactive SQL</title>
	<link rel="stylesheet" type="text/css" href="Style.css">
	
</head>

<body onload="hideshow()">

<?php
// Process the submitted form
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_SERVER['PHP_AUTH_USER'])) {
        $User = trim(strtoupper($_SERVER['PHP_AUTH_USER'])) ;
    }
    $ddname = "IntSQL$User";
    $getsub = "%SUBINTER";
    $dblayout = "InteractiveSQL";
    
    $ddheading = "IntSQL$User";
    if (isset($_POST['ddsql'])) {
        $ddsql =  str_replace("'","''",$_POST['ddsql']);
    }
    if (isset($_POST['ddsqltype'])) {
        $ddsqltype = $_POST['ddsqltype'];
    }
    
    // **********************************************************************
    // If send to screen, create all DB records
    // **********************************************************************
    if ($ddsqltype=='S') {
        // Update the record
        $conn = "*LOCAL";
        $i5link = db2_connect($conn, "","");
    
        // Check for existance of record
        $sql = "Select * from jerrymouse.dshhdrm where dbname = '$ddname'";
        $stmt = db2_prepare($i5link, $sql);
        $result = db2_execute($stmt);
        $row = db2_fetch_array($stmt);
        $dbtest = $row[0];
        
        if (trim($dbtest) <> trim($ddname)) {
          $sql = "Insert into jerrymouse.dshhdrm (dbname, dbtitle, dblayout, db#subs, dbludt, dblutm, dbluus, dblupg, dbstylsht, dbrfsec, dbrfurl, dblogo)
          values('$ddname','','$dblayout',0,0,0,' ',' ','StyleGrey.css', '0', ' ', ' ')";
          // echo $sql;
          // Execute SQL statement
          $stmt = db2_prepare($i5link, $sql); // or die("<p>Failed query:" . db2_stmt_error() . ":" . db2_stmt_errormsg() . "</p>");
          $result = db2_execute($stmt);
        }
        
        
        // Set security all access
        // Check for existance of record
        $sql = "Select * from jerrymouse.dshsecm where dsname = '$ddname' and dsuser = '*ALL'";
        $stmt = db2_prepare($i5link, $sql);
        $result = db2_execute($stmt);
        $row = db2_fetch_array($stmt);
        $dbtest = $row[0];
        $dbtest2 = $row[1];
        
        if (trim($dbtest) <> trim($ddname) or trim($dbtest2) <> '*ALL') {
            $sql = "Insert into jerrymouse.dshsecm (dsname, dsuser)
            values('$ddname','*ALL')";
            // echo $sql;
            // Execute SQL statement
            $stmt = db2_exec($i5link, $sql); // or die("<p>Failed query:" . db2_stmt_error() . ":" . db2_stmt_errormsg() . "</p>");
        }
        
        // Check for detail records that need to be created
        include_once 'authorization.php';
        include_once 'ToolkitService.php';
        include_once 'helpshow.php';
        
        $extension='ibm_db2';
        try {
            $ToolkitServiceObj = ToolkitService::getInstance($db, $user, $pass, $extension);
        }
        
        catch (Exception $e)
        {
            echo  $e->getMessage(), "\n";
            $dbbody = $e;
            exit();
        }
        $ToolkitServiceObj->setToolkitServiceParams(array('InternalKey'=>"/tmp/$user"));
        
        $param[] = $ToolkitServiceObj->AddParameterChar('both', 128,'DashBoardName', 'DBname', $ddname);
        $param[] = $ToolkitServiceObj->AddParameterChar('both', 50,'DashBoardDesc', 'DBDesc', $dblayout);
        
        $result = $ToolkitServiceObj->PgmCall("DSH0200C", "JERRYMOUSE", $param, null, null);
        
        
        //       Prepare SQL update - Update record
        
        $sql = "Update jerrymouse.dshdtlm set ddheading= '$ddheading', ddsql='$ddsql', ddsqltype = 'T' 
        WHERE ddname = '$ddname' and ddsub = '$getsub'";
        
        //echo $sql;
        //      Execute SQL statement
        $stmt = db2_exec($i5link,$sql)
        or die("<p>Failed query:". db2_stmt_error().":".db2_stmt_errormsg()."</p>");
    }
    
    // **********************************************************************
    // If download, call iQuery
    // **********************************************************************
    if ($ddsqltype=='D') {
        // Check for detail records that need to be created
        include_once 'authorization.php';
        include_once 'ToolkitService.php';
        include_once 'helpshow.php';
        
        $extension='ibm_db2';
        try {
            $ToolkitServiceObj = ToolkitService::getInstance($db, $user, $pass, $extension);
        }
        
        catch (Exception $e)
        {
            echo  $e->getMessage(), "\n";
            $dbbody = $e;
            exit();
        }
        $ToolkitServiceObj->setToolkitServiceParams(array('InternalKey'=>"/tmp/$user"));
        
        $ddemail = 'gregcannella@sbcglobal.net';
        
        $param[] = $ToolkitServiceObj->AddParameterChar('both', 5000,'SQL', 'DBSQL', $ddsql);
        $param[] = $ToolkitServiceObj->AddParameterChar('both', 100,'Email', 'DBEmail', $ddemail);
        
        $result = $ToolkitServiceObj->PgmCall("EML0010C", "JERRYMOUSE", $param, null, null);
        
        
    }
    
  
}

?>

	<div class="body-container">
		<img src="/JerryMouse/Images/YourLogo.png" alt="Powered By ScoreStory" height="100" width="200" align="right">
		
		<div class="text-container">	
				
				
				<?php 
				// Set parameters and call generate program
				//$ddname = $_GET['DB'];
				//$getsub = $_GET['SUB'];
				if (isset($_SERVER['PHP_AUTH_USER'])) {
				    $User = trim(strtoupper($_SERVER['PHP_AUTH_USER'])) ;
				}
				$ddname = "IntSQL$User";
				$getsub = "%SUBINTER";
				
				// DB2 Version
				$conn = "*LOCAL";
				$i5link = db2_connect($conn, "","");
				/* Construct the SQL statement */
				$sql = "SELECT * FROM JerryMouse.dshdtlm WHERE ddname = '$ddname' and ddsub = '$getsub'";
				
				/* Prepare, bind and execute the DB2 SQL statement */
				$stmt = db2_prepare($i5link,$sql);
				
				$flds = db2_num_fields($stmt);
				
				//Execute statement
				 
				$result = db2_execute($stmt);
				
				if (!$result) {
				    echo 'The db2 execute failed. ';
				    echo 'SQLSTATE value: ' . db2_stmt_error();
				    echo ' Message: ' .   db2_stmt_errormsg();
				    echo '<br>' . $sql;
				}
				else
				{
				    $row = db2_fetch_array($stmt);
				    $ddheading = $row[2];
				    $ddconturl = $row[3];
				    $ddprogram = $row[4];
				    $ddsql = $row[5];
				    //$ddsqltype = $row[6];
				    $ddlastrdt = $row[7];
				    $ddlastrtm = $row[8];
				    $ddrfshuom = $row[9];
				    $ddrfshunt = $row[10];
				    $ddludt = $row[11];
				    $ddlutm = $row[12];
				    $ddluus = $row[13];
				    $ddlupg = $row[14];
				    $ddredsign = $row[16];
				    $ddredvalue = $row[17];
				    $ddylwsign = $row[18];
				    $ddylwvalue = $row[19];
				    $ddgrnsign = $row[20];
				    $ddgrnvalue = $row[21];
				    $ddprepgm = $row[22];
				    
				    
				}
				//close connection
				db2_close($i5link);
				
				echo "<h1>Run Interactive SQL</h1>";
				?>
				
				
				<form method="post">
				<table class="table-noline">
				<tr>
				<td>
				<table class="table-noline">
				
				<tr>
				<td>
				<label for="ddsqltype">Output Type</label>
				</td>
				<td>
				<input type="radio" id="ddsqltype" name="ddsqltype" value="S" <?php if ($ddsqltype<>'D') {echo 'checked';}?> >Screen<br>
				<input type="radio" id="ddsqltype" name="ddsqltype" value="D" <?php if ($ddsqltype=='D') {echo 'checked';}?> >Download<br>
				</td>
				</tr>
				
				<tr>
				<td>
				<label for="ddsql">Content SQL</label>
				</td>
				<td>
				<textarea rows="10" cols="90" id="ddsql" name="ddsql" maxlength="2000"><?php echo trim($ddsql)?></textarea>
				</td>
				</tr>
				
				  
				</table>
				</td>
				</tr>
				<tr>
	            <td>
				<input type="submit" name="action" value="Run" />
				</td>
				</tr>
				</table>
				</form>
						    
                
			    <?php 	
			    if ($ddsqltype=='S') {
                    echo '<iframe src="showdashboard.php?DB=' . trim($ddname) . '" style="width: 1080px; height: 550px;">   </iframe>';
			    }    
		        ?>
		</div>
		
		<div class="footer">
			Powered by: ScoreStory		
		</div>

	</div>
	
</body>
</html>
