<!DOCTYPE html>
<html>
<head>
	<meta charset="UTF-8">
	<title>Set My Bookmarks - Add</title>
	<link rel="stylesheet" type="text/css" href="menuStyle.css">
	
	
</head>

<body>

<?php
// Process the submitted form
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    
    $dbDescription = $_POST['dbDesc'];
    $dbLink = $_POST['dbLink'];
    $dbImage = $_POST['dbImage'];
    $dbTarget = $_POST['dbTarget'];
    
    $user = trim(strtoupper($_SERVER['PHP_AUTH_USER'])) ;
    
    // Update the record
    $conn = "*LOCAL";
    $i5link = db2_connect($conn, "","");
    
    
    // Get next sequence number
    $seq = 0;
    $sql = "Select max(dbseq) from jerrymouse.dshbkmm where dbuser = '$user'";
    //      Execute SQL statement
    $stmt = db2_exec($i5link,$sql)
    or die("<p>Failed query:". db2_stmt_error().":".db2_stmt_errormsg()."</p>");
    // Get value from the file
    $row = db2_fetch_array($stmt);
    if ($row <> null) {
        $seq = $row[0];
        }
    $seq = $seq + 1;
    //echo $seq;
    
    
    //       Prepare SQL statement - Insert new record
    
    $sql = "Insert into jerrymouse.dshbkmm (dbuser,dbseq,dbdesc,dblink,dbimage,dbtarget) 
        values('$user',$seq,'$dbDescription','$dbLink','$dbImage','$dbTarget')";
    //echo $sql;
    //      Execute SQL statement
    $stmt = db2_exec($i5link,$sql)
    or die("<p>Failed query:". db2_stmt_error().":".db2_stmt_errormsg()."</p>");
    
    //close connection
	db2_close($i5link);
				
    header("Location: homepagebookmarks.php");
    exit;
    
  
}

?>
<div class="body-container">
  <form method="post">
  <header>
				<div class="headertext">Add a New Bookmark</div>
				</header>
				<img src="/JerryMouse/Images/YourLogo.png" alt="Powered By ScoreStory" height="100" width="200" align="right">
		
				<br>
				<table class="table-noline">
				<tr>
				<td>
				<label for="dbDesc">Description</label>
				</td>
				<td>
				<input id="dbDesc" name="dbDesc" size="50" />
				</td>
				</tr>
				
				<tr>
				<td>
				<label for="dbLink">Link</label>
				</td>
				<td>
				<input id="dbLink" name="dbLink" size="50"  />
				
				</td>
				</tr>
				
				<tr>
				<td>
				<label for="dbTarget">Target</label>
				</td>
				<td>
				<input list="dbTarget" name="dbTarget"  size="50" />
				<datalist id="dbTarget">
				  <option value="_blank">New Window</option>
				  <option value="_self">Same Frame</option>
				  <option value="_parent">Parent Frame</option>
				  <option value="_top">Same Window</option>
				</datalist>
				</td>
				</tr>
				
				<tr>
				<td>
				<label for="dbImage">Image</label>
				</td>
				<td>
				<input id="dbImage" name="dbImage"  size="50"/> <td>Image is optional.  If you 
				want to use an image, paste a link to the image. 
				Example: https://www.google.com/images/branding/googlelogo/1x/googlelogo_color_272x92dp.png</td>
				</td>
				</tr>
				
				 
				
				
	            <tr>
	            <td>
				<input type="submit" value="Add Link" />
				</td>
				</tr>  
				  </table>
				</form>
		
</div>	
</body>
</html>
				
