<?php
// Process the submitted form
    
    $dbName = $_GET['NAME'];
    
    $user = trim(strtoupper($_SERVER['PHP_AUTH_USER'])) ;
    
    // Update the record
    $conn = "*LOCAL";
    $i5link = db2_connect($conn, "","");
    
    
    // Get next sequence number
    
    $sql = "Delete from jerrymouse.dshuslm where ucuser = '$user' and ucname = '$dbName'";
    //      Execute SQL statement
    echo $sql;
    $stmt = db2_exec($i5link,$sql)
    or die("<p>Failed query:". db2_stmt_error().":".db2_stmt_errormsg()."</p>");
    
    //close connection
    db2_close($i5link);
    
    header("Location: homepagedashboards.php");
    exit;
    
  

?>