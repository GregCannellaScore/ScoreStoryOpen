<!DOCTYPE html>
<html>
<head>
	<meta charset="UTF-8">
	<title>Set My Dashoards</title>
	<link rel="stylesheet" type="text/css" href="menuStyle.css">
	
	
</head>

<body>

	<div class="body-container">
		
		<div class="text-container">	
		<header>
				<div class="headertext">Maintain My Dashboards</div>
				</header>
				<img src="/JerryMouse/Images/YourLogo.png" alt="Powered By ScoreStory" height="100" width="200" align="right">
		
				<br>
				<a href="Home_Page.php" class="button">Home Page</a>
	    
	            
                <table class="table-all-lines"><tr><th>Selected</th><th>Available</th>
                <tr>
                <td>
                <?php 
				// Get all of the current selected dashboards
				$user = trim(strtoupper($_SERVER['PHP_AUTH_USER'])) ;
				
				// DB2 Version
				$conn = "*LOCAL";
				$i5link = db2_connect($conn, "","");
				/* Construct the SQL statement */
				$sql = "SELECT * FROM jerrymouse.dshuslm where ucuser = '$user' order by ucseq";
				
				/* Prepare, bind and execute the DB2 SQL statement */
				$stmt = db2_prepare($i5link,$sql);
				
				$flds = db2_num_fields($stmt);
				
				//Execute statement
				 
				$result = db2_execute($stmt);
				
				if (!$result) {
				    echo 'The db2 execute failed. ';
				    echo 'SQLSTATE value: ' . db2_stmt_error();
				    echo ' Message: ' .   db2_stmt_errormsg();
				    echo '<br>' . $sql;
				}
				else
				{
				    echo '<table class="table-noborder">';
				    do {
				        $row = db2_fetch_array($stmt);
				        if ($row <> null) {
				            $dbUser = $row[0];
				            $dbName = $row[1];
				            $dbSeq = $row[2];
				            echo "<tr><td>$dbName</td>
				            <td><a href=" . '"' . "http:HomePageDashboardsRemove.php?NAME=$dbName". '"' . " class=". '"button"' . ">Remove</a> 
	                        </td></tr>";
				        }
				    } while ($row <> null);
				    echo "</table>";
				}
				
				?>
                
                </td>
                <td>
                <?php 
                
                // Put code to show all avaiable dashboards here
                /* Construct the SQL statement */
                $sql = "SELECT * FROM jerrymouse.dshdtlm where ddname like 'USER%' and ddname in 
                (select dsname from jerrymouse.dshsecm where dsuser = '$user' or dsuser = '*ALL') and ddname not in (select 
                ucname FROM jerrymouse.dshuslm where ucuser = '$user')
                order by ddname";
                
                /* Prepare, bind and execute the DB2 SQL statement */
                $stmt = db2_prepare($i5link,$sql);
                
                $flds = db2_num_fields($stmt);
                
                //Execute statement
                	
                $result = db2_execute($stmt);
                
                if (!$result) {
                    echo 'The db2 execute failed. ';
                    echo 'SQLSTATE value: ' . db2_stmt_error();
                    echo ' Message: ' .   db2_stmt_errormsg();
                    echo '<br>' . $sql;
                }
                else
                {
                    echo '<table class="table-noborder">';
                    do {
                        $row = db2_fetch_array($stmt);
                        if ($row <> null) {
                            $dbName = $row[0];
                            $dbTitle = $row[2];
                            echo "<tr><td>$dbName</td><td>$dbTitle</td>
                            <td><a href=" . '"' . "http:HomePageDashboardsSelect.php?NAME=$dbName". '"' . " class=". '"button"' . ">Select</a>
	                        </td></tr>";
                        }
                    } while ($row <> null);
                    echo "</table>";
                }
                //close connection
                db2_close($i5link);
                
                
                ?>
                </td>
                </tr>
                </table>
				
				
							
		</div>
		
		
	</div>
	
</body>
</html>
