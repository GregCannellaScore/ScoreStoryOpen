<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <link rel="stylesheet" type="text/css" href="menuStyle.css">
    <link href='http://fonts.googleapis.com/css?family=Lato:100,300,400,300italic' rel='stylesheet' type='text/css'>
    <title>Home Page Menu</title>
    <script src="sorttable.js"></script>

    
<script>
/* When the user clicks on the button, 
toggle between hiding and showing the dropdown content */
function myFunction() {
    document.getElementById("myDropdown").classList.toggle("show");
}

// Close the dropdown if the user clicks outside of it
window.onclick = function(event) {
  if (!event.target.matches('.dropbtn')) {

    var dropdowns = document.getElementsByClassName("dropdown-content");
    var i;
    for (i = 0; i < dropdowns.length; i++) {
      var openDropdown = dropdowns[i];
      if (openDropdown.classList.contains('show')) {
        openDropdown.classList.remove('show');
      }
    }
  }
}
</script>
    
    
    
</head>
<body>
<header>
<table class="headertable" width="100%"><tr><td width="10%" align="left">
<div class="dropdown">
<button onclick="myFunction()" class="dropbtn">&#9776;</button>
  <div id="myDropdown" class="dropdown-content">
    <a href="homepagebookmarks.php">Bookmarks</a>
    <a href="homepageDashboards.php">Dashboards</a>
  </div>
</div>

</td><td width="80%"><div class="headertext">Home Page</div></td><td width="10%"> </td></tr></table>

</header>

<div class="row">
<ul class="main-nav">

<li>
<a href="http://ScoreStory.com" target="_blank"><img src="YourLogo.png" width="180" height="80" title="ScoreStory.com"></a>
</li>    
<li>
<a href="https://google.com" target="_blank"><img src="Google Logo.png" width="180" height="80" title="Google"></a>
</li>
</ul>
<br>
</div>


<div class="row">
<div class="bookmarks">
<h3>My Bookmarks</h3>


</div>
</div>


<?php 

$user = trim(strtoupper($_SERVER['PHP_AUTH_USER'])) ;

// DB2 Version
$conn = "*LOCAL";
$i5link = db2_connect($conn, "","");
/* Construct the SQL statement */
$sql = "SELECT * FROM jerrymouse.dshbkmm where dbuser = '$user' order by dbseq";

/* Prepare, bind and execute the DB2 SQL statement */
$stmt = db2_prepare($i5link,$sql);

$flds = db2_num_fields($stmt);

//Execute statement
	
$result = db2_execute($stmt);

if (!$result) {
    echo 'The db2 execute failed. ';
    echo 'SQLSTATE value: ' . db2_stmt_error();
    echo ' Message: ' .   db2_stmt_errormsg();
    echo '<br>' . $sql;
}
else
{
    $rowCount = 0;
    $bookmarks = '<table class="bookmarktable"><tr>';
    do {
        $row = db2_fetch_array($stmt);
        if ($row <> null) {
          $dbuser = $row[0];
          $dbseq = $row[1];
          $dbdesc = $row[2];
          $dblink = $row[3];
          $dbimage = $row[4];
          $dbtarget = $row[5];
    
          $rowCount = $rowCount + 1;
          if ($rowCount == 6) {
            $bookmarks = $bookmarks . '</tr><tr>';
            $rowCount = 0;
          }
          $bookmarks = $bookmarks . '<td><a href="' . trim($dblink) . '" target ="' . trim($dbtarget) . '">';
          if (trim($dbimage) <> '') {
            $bookmarks = $bookmarks . '<img src="' . trim($dbimage) . '"' . 'title="' . trim($dbdesc) . '"></a>';
          } else {
            $bookmarks = $bookmarks . trim($dbdesc) . '</a>';
    
          }
          $bookmarks = $bookmarks . '</td>';
        }
    } while ($row <> null);    
    
    $bookmarks = $bookmarks . '</tr></table>';
}


echo $bookmarks;
include('HomePageDBSQL.php');

// Set parameters and call generate program


$dbbody = '';
HomePageDBSQLF($dbbody);

echo $dbbody;

?>

<br><br>

</body>
</html>