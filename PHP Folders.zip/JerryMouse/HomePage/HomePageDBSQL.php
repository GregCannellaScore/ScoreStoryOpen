<?php


function HomePageDBSQLF(&$pdbbody)
{
    $conn_resource = db2_connect("*LOCAL", "", "");
     
    if (!$conn_resource) {
        echo "Connection failed. SQL Err:";
        echo db2_conn_error();
        echo "<br>";
        echo db2_conn_errormsg();
    
        exit();
    }
    
    // echo "Executing  SQL statement: SELECT * FROM jerrymouse.ctm0550w for fetch only"."<br>", "<br>";
    
    /* Construct the SQL statement */
    $User = trim(strtoupper($_SERVER['PHP_AUTH_USER'])) ;
    //echo $User;
    $pdbparm = "USER" . $User;
    
    $sql = "SELECT jerrymouse.getdashboard(ddname,char('$User'),char('$pdbparm')) FROM jerrymouse.dshdtlm 
    where ddname in (select ucname from jerrymouse.dshuslm where ucuser = '$User') 
    and ddname in (select dsname from jerrymouse.dshsecm where dsuser = '$User' or dsuser = '*ALL')
    for fetch only ";
    
    //  " . {$_SERVER['PHP_AUTH_USER']} . "
    //echo $sql;
    /* Prepare, bind and execute the DB2 SQL statement */
    $stmt= db2_prepare($conn_resource, $sql);
    
    $flds = db2_num_fields($stmt);
    
    //Execute statement
     
    $result = db2_execute($stmt);
    
    if (!$result) {
        echo 'The db2 execute failed. ';
        echo 'SQLSTATE value: ' . db2_stmt_error();
        echo ' Message: ' .   db2_stmt_errormsg();
        echo '<br>' . $sql;
    }
    else
    {
        $DashBoardFound = 'N';
        while ($row = db2_fetch_array($stmt))
        {
            
            $file = rtrim($row[0]);
            $DashBoardFound = 'Y';
            
            // open file
            
            $fh = fopen($file, 'r') or die("Could not open file! $file ! ");
            
            // read file contents
            
            $pdbbody = $pdbbody . '<br><br>' . fread($fh, filesize($file)) . '<br>' or die("Could not read file! $file");
            
            // close file
            
            fclose($fh);
        }
        
        If ($DashBoardFound <> 'Y') {
        
            Echo 'You don' . "'" . 't have any dashboards selected.  To add a dashboard, select dashboards from the menu.' ;
        }
        
    }
    //close connection
    db2_close($conn_resource);
    
  
    
}
?>