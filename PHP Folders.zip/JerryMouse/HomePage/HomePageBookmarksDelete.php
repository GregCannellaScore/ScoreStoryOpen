<?php
// Process the submitted form
    
    $dbSeq = $_GET['SEQ'];
    
    $user = trim(strtoupper($_SERVER['PHP_AUTH_USER'])) ;
    
    // Update the record
    $conn = "*LOCAL";
    $i5link = db2_connect($conn, "","");
    
    
    // Get next sequence number
    
    $sql = "Delete from jerrymouse.dshbkmm where dbuser = '$user' and dbseq = $dbSeq";
    //      Execute SQL statement
    echo $sql;
    $stmt = db2_exec($i5link,$sql)
    or die("<p>Failed query:". db2_stmt_error().":".db2_stmt_errormsg()."</p>");
    
    //close connection
    db2_close($i5link);
    
    header("Location: homepagebookmarks.php");
    exit;
    
  

?>