<!DOCTYPE html>
<html>
<head>
	<meta charset="UTF-8">
	<title>Set My Bookmarks - Edit</title>
	<link rel="stylesheet" type="text/css" href="menuStyle.css">
	
	
</head>

<body>

<?php
// Process the submitted form
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    
    $dbDescription = $_POST['dbDesc'];
    $dbLink = $_POST['dbLink'];
    $dbImage = $_POST['dbImage'];
    $dbTarget = $_POST['dbTarget'];
    $dbSeq = $_POST['dbSeq'];
    
    $user = trim(strtoupper($_SERVER['PHP_AUTH_USER'])) ;
    
    // Update the record
    $conn = "*LOCAL";
    $i5link = db2_connect($conn, "","");
    
    
    
    
    //       Prepare SQL statement - Update record
    
    $sql = "Update jerrymouse.dshbkmm set dbdesc='$dbDescription', dblink='$dbLink', dbimage='$dbImage'
        , dbtarget='$dbTarget' where dbuser = '$user' and dbseq = $dbSeq";
    //echo $sql;
    //      Execute SQL statement
    $stmt = db2_exec($i5link,$sql)
    or die("<p>Failed query:". db2_stmt_error().":".db2_stmt_errormsg()."</p>");
    
    //close connection
	db2_close($i5link);
				
    header("Location: homepagebookmarks.php");
    exit;
    
  
}
//******************************************************
// Get the data from the file
$dbSeq = $_GET['SEQ'];

$user = trim(strtoupper($_SERVER['PHP_AUTH_USER'])) ;

// DB2 Version
$conn = "*LOCAL";
$i5link = db2_connect($conn, "","");
/* Construct the SQL statement */
$sql = "SELECT * FROM jerrymouse.dshbkmm where dbuser = '$user' and dbseq = $dbSeq";

/* Prepare, bind and execute the DB2 SQL statement */
$stmt = db2_prepare($i5link,$sql);

$flds = db2_num_fields($stmt);

//Execute statement

$result = db2_execute($stmt);

if (!$result) {
    echo 'The db2 execute failed. ';
    echo 'SQLSTATE value: ' . db2_stmt_error();
    echo ' Message: ' .   db2_stmt_errormsg();
    echo '<br>' . $sql;
}
else
{
    $rowCount = 0;
    $bookmarks = '<table class="bookmarktable"><tr>';
    $row = db2_fetch_array($stmt);
        if ($row <> null) {
            $dbUser = $row[0];
            $dbSeq = $row[1];
            $dbDesc = $row[2];
            $dbLink = $row[3];
            $dbImage = $row[4];
            $dbTarget = $row[5];

            }
    
}
//close ection
db2_close($i5link);

//*******************************************************
?>
<div class="body-container">
  <form method="post">
  <header>
				<div class="headertext">Edit Bookmark</div>
				</header>
				<img src="/JerryMouse/Images/YourLogo.png" alt="Powered By ScoreStory" height="100" width="200" align="right">
		
				<br>
	
				<table class="table-noline">
				<tr>
				<td>
				<label for="dbDesc">Description</label>
				</td>
				<td>
				<input id="dbDesc" name="dbDesc" size="50"  value="<?php echo trim($dbDesc)?>" />
				</td>
				</tr>
				
				<tr>
				<td>
				<label for="dbLink">Link</label>
				</td>
				<td>
				<input id="dbLink" name="dbLink" size="50"  value="<?php echo trim($dbLink)?>" />
				
				</td>
				</tr>
				
				<tr>
				<td>
				<label for="dbTarget">Target</label>
				</td>
				<td>
				<input list="dbTarget" name="dbTarget"  size="50"  value="<?php echo trim($dbTarget)?>" />
				<datalist id="dbTarget">
				  <option value="_blank">New Window</option>
				  <option value="_self">Same Frame</option>
				  <option value="_parent">Parent Frame</option>
				  <option value="_top">Same Window</option>
				</datalist>
				</td>
				</tr>
				
				<tr>
				<td>
				<label for="dbImage">Image</label>
				</td>
				<td>
				<input id="dbImage" name="dbImage"  size="50"  value="<?php echo trim($dbImage)?>" /></td> 
				<td>Image is optional.  If you 
				want to use an image, paste a link to the image. 
				Example: https://www.google.com/images/branding/googlelogo/1x/googlelogo_color_272x92dp.png</td>
				</tr>
				
				<tr>
				<td>
				<label for="dbSeq"> </label>
				</td>
				<td>
				<input type="hidden" name="dbSeq"  value="<?php echo trim($dbSeq)?>" />
				</td>
				</tr>
				 
				
				
	            <tr>
	            <td>
				<input type="submit" value="Update Link" />
				</td>
				</tr>  
				  </table>
				</form>
		
</div>	
</body>
</html>
				
