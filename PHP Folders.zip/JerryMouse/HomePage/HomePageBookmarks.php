<!DOCTYPE html>
<html>
<head>
	<meta charset="UTF-8">
	<title>Set My Bookmarks</title>
	<link rel="stylesheet" type="text/css" href="menuStyle.css">
	
	
</head>

<body>

	<div class="body-container">
		<div class="text-container">	
				
				<header>
				<div class="headertext">My Bookmarks</div>
				</header>
				<img src="/JerryMouse/Images/YourLogo.png" alt="Powered By ScoreStory" height="100" width="200" align="right">
		
				<br>
				<a href="Home_Page.php" class="button">Home Page</a>
	    
	            <form action="http:HomePageBookmarksAdd.php">
                   <input type="submit" value="Add Bookmark" />
                </form><br>
				<?php 
				// Set parameters and call generate program
				
				$user = trim(strtoupper($_SERVER['PHP_AUTH_USER'])) ;
				
				// DB2 Version
				$conn = "*LOCAL";
				$i5link = db2_connect($conn, "","");
				/* Construct the SQL statement */
				$sql = "SELECT * FROM jerrymouse.dshbkmm where dbuser = '$user' order by dbseq";
				
				/* Prepare, bind and execute the DB2 SQL statement */
				$stmt = db2_prepare($i5link,$sql);
				
				$flds = db2_num_fields($stmt);
				
				//Execute statement
				 
				$result = db2_execute($stmt);
				
				if (!$result) {
				    echo 'The db2 execute failed. ';
				    echo 'SQLSTATE value: ' . db2_stmt_error();
				    echo ' Message: ' .   db2_stmt_errormsg();
				    echo '<br>' . $sql;
				}
				else
				{
				    $row = db2_fetch_array($stmt);
				    if ($row <> null) {
				    echo '<table class="table-all-lines"><tr><th>Description</th><th>Link</th><th>Actions</th></tr>';
				      do {
				          if ($row <> null) {
				              $dbUser = $row[0];
				              $dbSeq = $row[1];
				              $dbDesc = $row[2];
				              $dbLink = $row[3];
				              $dbImage = $row[4];
				              $dbTarget = $row[5];
				              echo "<tr><td>$dbDesc</td><td>$dbLink</td>
				              <td><a href=" . '"' . "http:HomePageBookmarksUp.php?SEQ=$dbSeq". '"' . " class=". '"button"' . ">Move Up</a> 
				              <a href=" . '"' . "http:HomePageBookmarksDown.php?SEQ=$dbSeq". '"' . " class=". '"button"' . ">Move Down</a>
				              <a href=" . '"' . "http:HomePageBookmarksEdit.php?SEQ=$dbSeq". '"' . " class=". '"button"' . ">Edit</a>
				              <a href=" . '"' . "http:HomePageBookmarksDelete.php?SEQ=$dbSeq". '"' . " class=". '"button"' . ">Delete</a></td></tr>";
				          }
				          $row = db2_fetch_array($stmt);
				      } while ($row <> null);
				      echo "</table>";
				      //close connection
				      db2_close($i5link);
				      
				    }
				    else {
				        echo "You don't have any bookmarks.  Click Add to add a bookmark"; 
				    }
				}
				
				?>
				
							
		</div>
		
		
	</div>
	
</body>
</html>
