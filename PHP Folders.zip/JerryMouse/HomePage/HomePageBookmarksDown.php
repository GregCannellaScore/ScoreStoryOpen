<?php
// Move the current selected bookmark down
    
    $dbSeq = $_GET['SEQ'];
    
    $user = trim(strtoupper($_SERVER['PHP_AUTH_USER'])) ;
    
    // Update the record
    $conn = "*LOCAL";
    $i5link = db2_connect($conn, "","");
    
    // Get the current highest number
    $sql = "Select max(dbseq) from jerrymouse.dshbkmm where dbuser = '$user'";
    //      Execute SQL statement
    $stmt = db2_exec($i5link,$sql)
    or die("<p>Failed query:". db2_stmt_error().":".db2_stmt_errormsg()."</p>");
    // Get value from the file
    $row = db2_fetch_array($stmt);
    if ($row <> null) {
        $maxSeq = $row[0];
    }
    if ($dbSeq == $maxSeq) {
        db2_close($i5link);
        header("Location: homepagebookmarks.php");
        exit;
    }
    
    // Move current number out of the way
    
    $sql = "Update jerrymouse.dshbkmm set dbseq = 99999 where dbuser = '$user' and dbseq = $dbSeq";
    $stmt = db2_exec($i5link,$sql)
    or die("<p>Failed query:". db2_stmt_error().":".db2_stmt_errormsg()."</p>");
    
    // Move one bellow up (make the sequence number on smaller)
    $oneAfter = $dbSeq +1;
    $sql = "Update jerrymouse.dshbkmm set dbseq = $dbSeq where dbuser = '$user' and dbseq = $oneAfter";
    $stmt = db2_exec($i5link,$sql)
    or die("<p>Failed query:". db2_stmt_error().":".db2_stmt_errormsg()."</p>");
    
    // Move saved one up (make the sequence number one smaller)
    $sql = "Update jerrymouse.dshbkmm set dbseq = $oneAfter where dbuser = '$user' and dbseq = 99999";
    $stmt = db2_exec($i5link,$sql)
    or die("<p>Failed query:". db2_stmt_error().":".db2_stmt_errormsg()."</p>");
    db2_close($i5link);
    
    
    header("Location: homepagebookmarks.php");
    exit;
    
  

?>