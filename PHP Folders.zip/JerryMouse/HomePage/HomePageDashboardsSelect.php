<?php
// Process the submitted form
    
    $dbName = $_GET['NAME'];
    
    $user = trim(strtoupper($_SERVER['PHP_AUTH_USER'])) ;
    
    // Update the record
    $conn = "*LOCAL";
    $i5link = db2_connect($conn, "","");
    
    
    // Get next sequence number
    $seq = 0;
    $sql = "Select max(ucseq) from jerrymouse.dshuslm where ucuser = '$user'";
    //      Execute SQL statement
    $stmt = db2_exec($i5link,$sql)
    or die("<p>Failed query:". db2_stmt_error().":".db2_stmt_errormsg()."</p>");
    // Get value from the file
    $row = db2_fetch_array($stmt);
    if ($row <> null) {
        $seq = $row[0];
    }
    $seq = $seq + 1;
    
    // Get last update date & time
    $today = date("ymd") + 1000000;
    $now = date("His");
    
    // Insert record
    $sql = "Insert into jerrymouse.dshuslm (ucuser, ucname, ucseq, ucludt, uclutm, ucluus, uclupg) 
    values('$user', '$dbName', $seq, $today, $now, '$user', 'PHP' )";
    //      Execute SQL statement
    echo $sql;
    $stmt = db2_exec($i5link,$sql)
    or die("<p>Failed query:". db2_stmt_error().":".db2_stmt_errormsg()."</p>");
    
    //close connection
    db2_close($i5link);
    
    header("Location: homepagedashboards.php");
    exit;
    
  

?>