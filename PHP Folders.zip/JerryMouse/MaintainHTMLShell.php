    <!DOCTYPE html>
<html>
<head>
	<meta charset="UTF-8">
	<title>Maintain Dashboard Shells</title>
	<link rel="stylesheet" type="text/css" href="Style.css">
	

</head>

<body>

<?php
// Process the submitted form
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    
    $ddname = $_GET['HTMLName'];
    $ddtext =  str_replace("'","''",$_POST['ddtext']); 
    $ddSubValue1 =  str_replace("'","''",$_POST['ddSubValue1']);
    $ddSubValue2 =  str_replace("'","''",$_POST['ddSubValue2']);
    $ddSubValue3 =  str_replace("'","''",$_POST['ddSubValue3']);
    $ddSubValue4 =  str_replace("'","''",$_POST['ddSubValue4']);
    $ddSubValue5 =  str_replace("'","''",$_POST['ddSubValue5']);
    $ddSubValue6 =  str_replace("'","''",$_POST['ddSubValue6']);
    $ddSubValue7 =  str_replace("'","''",$_POST['ddSubValue7']);
    $ddSubValue8 =  str_replace("'","''",$_POST['ddSubValue8']);
    $ddSubValue9 =  str_replace("'","''",$_POST['ddSubValue9']);
    $ddSubValue10 =  str_replace("'","''",$_POST['ddSubValue10']);
       
    
    // Update the record
    $conn = "*LOCAL";
    $i5link = db2_connect($conn, "","");
    
    //       Prepare SQL statement - Insert new record
    
    $sql = "Update jerrymouse.htmlbdm set hxbody = '$ddtext', hxsub1 = '$ddSubValue1', hxsub2 = '$ddSubValue2', 
    hxsub3 = '$ddSubValue3', hxsub4 = '$ddSubValue4', hxsub5 = '$ddSubValue5', hxsub6 = '$ddSubValue6', 
    hxsub7 = '$ddSubValue7', hxsub8 = '$ddSubValue8', hxsub9 = '$ddSubValue9', hxsub10= '$ddSubValue10'
    WHERE hxbodyname = '$ddname' ";
    echo $sql;
    //      Execute SQL statement
    $stmt = db2_exec($i5link,$sql)
    or die("<p>Failed query:". db2_stmt_error().":".db2_stmt_errormsg()."</p>");
    
       
    header("Location: /jerrymouse/maintainhtmlshellsuccess.html");
    exit;
    
  
}

?>

	<div class="body-container">
		<img src="/JerryMouse/Images/YourLogo.png" alt="Powered By ScoreStory" height="100" width="200" align="right">
		
		<div class="text-container">	
				
				
				<?php 
				// Set parameters and call generate program
				if (isset($_GET['HTMLName'])) {
				    $ddname = $_GET['HTMLName'];
				}				
				
				// DB2 Version
				$conn = "*LOCAL";
				$i5link = db2_connect($conn, "","");
				/* Construct the SQL statement */
				$sql = "SELECT * FROM jerrymouse.htmlbdm WHERE hxbodyname = '$ddname' ";
				
				/* Prepare, bind and execute the DB2 SQL statement */
				$stmt = db2_prepare($i5link,$sql);
				
				$flds = db2_num_fields($stmt);
				
				//Execute statement
				 
				$result = db2_execute($stmt);
				
				if (!$result) {
				    echo 'The db2 execute failed. ';
				    echo 'SQLSTATE value: ' . db2_stmt_error();
				    echo ' Message: ' .   db2_stmt_errormsg();
				    echo '<br>' . $sql;
				}
				else
				{
				    $row = db2_fetch_array($stmt);
				    $ddtext = $row[1];
				    $ddSubValue1 = $row[2];
				    $ddSubValue2 = $row[3];
				    $ddSubValue3 = $row[4];
				    $ddSubValue4 = $row[5];
				    $ddSubValue5 = $row[6];
				    $ddSubValue6 = $row[7];
				    $ddSubValue7 = $row[8];
				    $ddSubValue8 = $row[9];
				    $ddSubValue9 = $row[10];
				    $ddSubValue10 = $row[11];
				}
				echo "<h1>Maintain HTML - $ddname</h1>";
				?>
				
				
				<form method="post">
				<table class="table-noline">
							
				
				<tr>
				<td>
				<label for="ddtext">Shell Body</label>
				</td>
				<td>
				<textarea rows="15" cols="100" id="ddtext" name="ddtext" maxlength="5000"><?php echo trim($ddtext)?></textarea>
				</td>
				</tr>
				
				<tr><td>
				<label for="ddSubValue1">Sub Value 1</label>
				</td><td>
				<input type="text" name="ddSubValue1" id="ddSubValue1" value = "<?php echo trim($ddSubValue1)?>" />
				</td></tr>
								
				<tr><td>
				<label for="ddSubValue2">Sub Value 2</label>
				</td><td>
				<input type="text" name="ddSubValue2" id="ddSubValue2" value = "<?php echo trim($ddSubValue2)?>" />
				</td></tr>
				
				<tr><td>
				<label for="ddSubValue3">Sub Value 3</label>
				</td><td>
				<input type="text" name="ddSubValue3" id="ddSubValue3" value = "<?php echo trim($ddSubValue3)?>" />
				</td></tr>
				
				<tr><td>
				<label for="ddSubValue4">Sub Value 4</label>
				</td><td>
				<input type="text" name="ddSubValue4" id="ddSubValue4" value = "<?php echo trim($ddSubValue4)?>" />
				</td></tr>
				
				<tr><td>
				<label for="ddSubValue5">Sub Value 5</label>
				</td><td>
				<input type="text" name="ddSubValue5" id="ddSubValue5" value = "<?php echo trim($ddSubValue5)?>" />
				</td></tr>
				
				<tr><td>
				<label for="ddSubValue6">Sub Value 6</label>
				</td><td>
				<input type="text" name="ddSubValue6" id="ddSubValue6" value = "<?php echo trim($ddSubValue6)?>" />
				</td></tr>
				
				<tr><td>
				<label for="ddSubValue7">Sub Value 7</label>
				</td><td>
				<input type="text" name="ddSubValue7" id="ddSubValue7" value = "<?php echo trim($ddSubValue7)?>" />
				</td></tr>
				
				<tr><td>
				<label for="ddSubValue8">Sub Value 8</label>
				</td><td>
				<input type="text" name="ddSubValue8" id="ddSubValue8" value = "<?php echo trim($ddSubValue8)?>" />
				</td></tr>
				
				<tr><td>
				<label for="ddSubValue9">Sub Value 9</label>
				</td><td>
				<input type="text" name="ddSubValue9" id="ddSubValue9" value = "<?php echo trim($ddSubValue9)?>" />
				</td></tr>
				
				<tr><td>
				<label for="ddSubValue10">Sub Value 10</label>
				</td><td>
				<input type="text" name="ddSubValue10" id="ddSubValue10" value = "<?php echo trim($ddSubValue10)?>" />
				</td></tr>
				
				</table>
				</td>
				</tr>
				<tr>
	            <td>
				<input type="submit" name="action" value="Update" />
				</td>
				</tr>
				</table>
				</form>
						    
                
			
		</div>
		
		<div class="footer">
			Powered by: ScoreStory
		</div>

	</div>
	
</body>
</html>
