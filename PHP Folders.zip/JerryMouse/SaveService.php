<?php

    $sqlvalue = str_replace("'","''",$_GET['SQL']);
    
    // Update the record
    $conn = "*LOCAL";
    $i5link = db2_connect($conn, "","");
    
    $sql = "Update jerrymouse.dshdtlm set ddsql='$sqlvalue'  
    WHERE ddname = 'SERVICE_RUN' and ddsub = '%SUBCELL001'";
    //echo $sql;
    //      Execute SQL statement
    $stmt = db2_exec($i5link,$sql)
    or die("<p>Failed query:". db2_stmt_error().":".db2_stmt_errormsg()."</p>");
    header("location: /Jerrymouse/showdashboard.php?DB=SERVICE_RUN" );
    exit;

?>
