<?php
session_start();
?>
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Add Security Access</title>
<link rel="stylesheet" type="text/css" href="Style.css">


</head>

<body>

<?php
if ($_SERVER['REQUEST_METHOD'] <> 'POST') {
    $_SESSION["gobackto"] = $_SERVER['HTTP_REFERER'];
}

// Process the submitted form
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    
    // Get POST variables
    $dsname = $_POST['dsname'];
    $dsuser = $_POST['dsuser'];
    
    // DB2 Version
    $conn = "*LOCAL";
    $i5link = db2_connect($conn, "", "");
    
    // Insert new record
    
    $sql = "Insert into jerrymouse.dshsecm (dsname,dsuser) values(?,?)";
    $parms = array($dsname,strtoupper($dsuser));
     
    
    //echo $sql;
    $stmt = db2_prepare($i5link, $sql);
    $result = db2_execute($stmt, $parms);
    if (!$result) {
        "<p>Failed query:" . db2_stmt_error() . ":" . db2_stmt_errormsg() . "</p>";
        exit();
    }
    
    // close connection
    db2_close($i5link);
    
    $gobackto = 'Location: ' . $_SESSION["gobackto"];
    header($gobackto);
    exit();
}

?>

	<div class="body-container">
		<div class="text-container">	

<?php
    $dsname = $_GET['DB'];
    
?>
            <h1>Add Security Access</h1>
				
			<form method="post" enctype="multipart/form-data" action="">
			<table class="table-noline">
				<tr>
					<td><label for="dsname">Dashboard Name</label></td>
					<td><input id="dsname" name="dsname" readonly value="<?php echo trim($dsname)?>"/></td>
				</tr>

				<tr>
					<td><label for="dsuser">User/Group/*ALL</label></td>
					<td><input id="dsuser" name="dsuser" size="10" /> </td>
				</tr>
				
				<tr>
					<td><input type="submit" value="Grant Access" /></td>
				</tr>
			</table>
		</form>



		</div>

	</div>

</body>
</html>
