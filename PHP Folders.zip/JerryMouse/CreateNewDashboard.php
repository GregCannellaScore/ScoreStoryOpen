<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Create New Dashboard</title>
<link rel="stylesheet" type="text/css" href="Style.css">



<?php
// Process the submitted form
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    
    $dbname = $_POST['dbName'];
    header("Location: NewDashboardHeader.php?DB=$dbname");
    exit();
    
}
?>

</head>

<body>
       <div class="body-container">

		<div class="text-container">
        	<h1>Create New Dashboard</h1>
			<br>

			<form method="post" action="">

				<table>
					<tr>
						<td>Enter the name of your new dashboard:</td>
						<td><input id="dbName" name="dbName" size="50" /></td>
					</tr>
				</table>	
					<br/>If you want to make the dashboard available to the menu, use the create menu part option.<br /><br />
					<input type="submit" value="Continue" />
				
			</form>
			<br>
                           
                                                
        </div>
        
        <div class="footer">
			Powered by: ScoreStory		
		</div>

	</div>

</body>
</html>
