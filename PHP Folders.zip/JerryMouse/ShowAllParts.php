<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Show All Menu Parts</title>
<link rel="stylesheet" type="text/css" href="Style.css">


</head>

<body>
<?php

//$user = trim(strtoupper($_SERVER['PHP_AUTH_USER']));
//if ($user<>'GREGC') {
//    echo "You dont have access to this screen.";
//    exit;
//}
?>
       <div class="body-container">

		<div class="text-container">
			<h1>Show All Menu Dashboard Parts</h1>
			<br>

			<br>
                     <?php
                    // DB2 Version
                    $conn = "*LOCAL";
                    $i5link = db2_connect($conn, "", "");
                    /* Construct the SQL statement */
                    $sql = "SELECT * FROM jerrymouse.dshdtlm where ddname like 'USER%' order by ddname";
                    // echo $sql;
                    /* Prepare, bind and execute the DB2 SQL statement */
                    $stmt = db2_prepare($i5link, $sql);
                    
                    $flds = db2_num_fields($stmt);
                    
                    // Execute statement
                    
                    $result = db2_execute($stmt);
                    
                    if (! $result) {
                        echo 'The db2 execute failed. ';
                        echo 'SQLSTATE value: ' . db2_stmt_error();
                        echo ' Message: ' . db2_stmt_errormsg();
                        echo '<br>' . $sql;
                    } else {
                        echo '<table class="table-all-lines"><tr><th>Actions</th><th>Dashboard Name</th><th>Heading</th></tr>';
                        do {
                            $row = db2_fetch_array($stmt);
                            if ($row != null) {
                                $ddname = $row[0];
                                $ddsub = $row[1];
                                $ddheading = $row[2];
                                
                                echo "<tr><td><a href=" . '"' . "http:maintdbdetail.php?DB=$ddname&SUB=%SUBCELL1" . '"' . " class=" . '"button"' . ">Edit</a>
                                      <a href=" . '"' . "http:maintdbsecurity.php?DB=$ddname" . '"' . " class=" . '"button"' . ">Security</a>
                                      <td>$ddname</td><td>$ddheading</td></tr>";
                                
                            }
                        } while ($row != null);
                        echo "</table>";
                    }
                    // close connection
                    db2_close($i5link);
                    
                    ?>
                           
                                                
              </div>
        
        <div class="footer">
			Powered by: ScoreStory		
		</div>

	</div>

</body>
</html>
