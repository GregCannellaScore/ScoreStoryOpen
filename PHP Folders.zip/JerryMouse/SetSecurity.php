<!DOCTYPE html>
<html>
<head>
	<meta charset="UTF-8">
	<title>Set Security</title>
	<link rel="stylesheet" type="text/css" href="Style.css">
	
	
</head>

<body>

<?php
// Process the submitted form
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    
    $dbuser = $_POST['dbuser'];
    
    //set current date in format cyymmdd to update header file
    //$str = (($n = date('Y')) >= 2000? intval(($n-2000)/100)+1 : 0) . date('cymd'); 
    $str = date('Ymd');
    
    // Update the record
    $conn = "*LOCAL";
    $i5link = db2_connect($conn, "","");
    
    //       Prepare SQL statement - Insert new record into code category
    $sql = "Insert into jerrymouse.codecat (cccatc, cccatk, cclpgm, cclusr, ccldte, ccltim) 
            values('JMAUTMNT',upper('$dbuser'),'','',CAST($str As numeric(8,0)),CAST(CURRENT TIME As numeric(6,0)))";
    //echo $sql;
    //      Execute SQL statement
    $stmt = db2_exec($i5link,$sql)
    or die("<p>Failed query:". db2_stmt_error().":".db2_stmt_errormsg()."</p>");
    
    //       Prepare SQL statement - Insert new record into code category user file
    $sql = "Insert into jerrymouse.codusrm (cuuser, cucatc, culusr, culdte, cultim)
    values(upper('$dbuser'),'JMAUTMNT','',CAST($str As numeric(8,0)),CAST(CURRENT TIME As numeric(6,0)))";
    //echo $sql;
    //      Execute SQL statement
    $stmt = db2_exec($i5link,$sql)
    or die("<p>Failed query:". db2_stmt_error().":".db2_stmt_errormsg()."</p>");
    
    //       Prepare SQL statement - Insert all new records into program security file
    $sql = "Insert into jerrymouse.pgmsec (psuser, pspgm, psopt1, psopt2, psopt3, psopt4, psopt5, pslpgm, pslusr, psldte, psltim)
           select upper('$dbuser'),pspgm, psopt1, psopt2, psopt3, psopt4, psopt5,'','',CAST($str As numeric(8,0)),CAST(CURRENT TIME As numeric(6,0))
           from jerrymouse.pgmsec where psuser='GREGC'";
    //echo $sql;
    //      Execute SQL statement
    $stmt = db2_exec($i5link,$sql)
    or die("<p>Failed query:". db2_stmt_error().":".db2_stmt_errormsg()."</p>");
    
    //       Prepare SQL statement - Insert a menu user name
    $sql = "Insert into jerrymouse.mnuusrm (muuser, muimenu, museclvl, mucmenu, mucustm, muludt, mulutm, muluus, mulupg)
    select upper('$dbuser'),muimenu, museclvl, mucmenu, mucustm, muludt, mulutm, muluus, mulupg
    from jerrymouse.mnuusrm where muuser='GREGC'";
    //echo $sql;
    //      Execute SQL statement
    $stmt = db2_exec($i5link,$sql)
    or die("<p>Failed query:". db2_stmt_error().":".db2_stmt_errormsg()."</p>");
    
    //close connection
	db2_close($i5link);
	
	// Check for detail records that need to be created
		
    header("Location: /jerrymouse/index.html");
    exit;
    
  
}

?>

	<div class="body-container">
		<img src="/JerryMouse/Images/YourLogo.png" alt="Powered By ScoreStory" height="100" width="200" align="right">
		
		<div class="text-container">	
				
				
				<?php 
				// Set parameters and call generate program
				
				echo "<h1>Set ScoreStory Security Officer</h1>";
				
				// DB2 Version
				$conn = "*LOCAL";
				$i5link = db2_connect($conn, "","");
				/* Construct the SQL statement */
				$sql = "SELECT count(*) FROM JerryMouse.codecat where cccatc = 'JMAUTMNT' and cccatk <> 'GREGC'";
				
				/* Prepare, bind and execute the DB2 SQL statement */
				$stmt = db2_prepare($i5link,$sql);
				
				$flds = db2_num_fields($stmt);
				
				//Execute statement
				 
				$result = db2_execute($stmt);
				
				if (!$result) {
				    echo 'The db2 execute failed. ';
				    echo 'SQLSTATE value: ' . db2_stmt_error();
				    echo ' Message: ' .   db2_stmt_errormsg();
				    echo '<br>' . $sql;
				}
				else
				{
				    $row = db2_fetch_array($stmt);
				    $countauth = $row[0];
				        
				}
    				//close connection
    				db2_close($i5link);
    			
				if ($countauth == 0) {
				echo '
				<form method="post">
				<table class="table-noline">
				<tr>
				<td>
				<label for="dbuser">Enter the name of the user that will be security officer for ScoreStory software.</label>
				</td>
				<td>
				<input id="dbuser" name="dbuser" maxlength="10"/>
				</td>
				</tr>
                <tr>
					<td><input type="submit" value="Submit" /></td>
				</tr>
				</table>
				</form>';
				echo "If you ever need to reset the admin user profile, remove all records from codes category JMAUTMNT.  The following SQL 
				will accomplish this. <br>
				delete from jerrymouse.codecat where cccatc = 'JMAUTMNT'";
				}
				else {
				    echo "The admin user profile has been set.  If you need to reset this user profile, call for support.";
				}
				
				?>
				
                
			
		</div>
		
		<div class="footer">
			Powered by: ScoreStory		
		</div>

	</div>
	
</body>
</html>
