<!DOCTYPE html>
<html>
<head>
	<meta charset="UTF-8">
	<title>Show Dashboard</title>
	<link rel="stylesheet" type="text/css" href="Style.css">
	
	
</head>

<body>

<?php
// Process the submitted form
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    
    $dbname = $_GET['DB'];
    $dbtitle = $_POST['dbtitle'];
    $dblayout = $_POST['dblayout'];
    $dbstylsht = $_POST['dbstylsht'];
    $dbrfsec = $_POST['dbrfsec'];
    $dbrfurl = $_POST['dbrfurl'];
    $dblogo = $_POST['dblogo'];
    
    //set current date in format cyymmdd to update header file
    $str = (($n = date('Y')) >= 2000? intval(($n-2000)/100)+1 : 0) . date('ymd'); 
    
    // Update the record
    $conn = "*LOCAL";
    $i5link = db2_connect($conn, "","");
    
    //       Prepare SQL statement - Insert new record
    
    $sql = "Update jerrymouse.dshhdrm set dbtitle= '$dbtitle', dblayout='$dblayout',
            dbstylsht= '$dbstylsht', dbrfsec='$dbrfsec', dbrfurl='$dbrfurl',
            dbludt = CAST($str As numeric(7,0)),
            dblutm = CAST(CURRENT TIME As numeric(6,0)),
            dblogo ='$dblogo' 
            WHERE dbname = '$dbname'";
    //echo $sql;
    //      Execute SQL statement
    $stmt = db2_exec($i5link,$sql)
    or die("<p>Failed query:". db2_stmt_error().":".db2_stmt_errormsg()."</p>");
    
    //close connection
	db2_close($conn);
	
	// Check for detail records that need to be created
	include_once 'authorization.php';
	include_once 'ToolkitService.php';
	include_once 'helpshow.php';
	
	$extension='ibm_db2';
	try {
	    $ToolkitServiceObj = ToolkitService::getInstance($db, $user, $pass, $extension);
	}
	
	catch (Exception $e)
	{
	    echo  $e->getMessage(), "\n";
	    $dbbody = $e;
	    exit();
	}
	$ToolkitServiceObj->setToolkitServiceParams(array('InternalKey'=>"/tmp/$user"));
	
	$param[] = $ToolkitServiceObj->AddParameterChar('both', 128,'DashBoardName', 'DBname', $dbname);
	$param[] = $ToolkitServiceObj->AddParameterChar('both', 50,'DashBoardDesc', 'DBDesc', $dblayout);
	
	$result = $ToolkitServiceObj->PgmCall("DSH0200C", "JERRYMOUSE", $param, null, null);
	
	
	
	
    header("Location: /jerrymouse/showdashboard.php?DB=$dbname");
    exit;
    
  
}

?>

	<div class="body-container">
		<img src="/JerryMouse/Images/YourLogo.png" alt="Powered By ScoreStory" height="100" width="200" align="right">
		
		<div class="text-container">	
				
				
				<?php 
				// Set parameters and call generate program
				$dbname = $_GET['DB'];
				echo "<h1>Maintain Dashboard - $dbname</h1>";
				
				// DB2 Version
				$conn = "*LOCAL";
				$i5link = db2_connect($conn, "","");
				/* Construct the SQL statement */
				$sql = "SELECT * FROM JerryMouse.dshhdrm where dbname = '$dbname'";
				
				/* Prepare, bind and execute the DB2 SQL statement */
				$stmt = db2_prepare($i5link,$sql);
				
				$flds = db2_num_fields($stmt);
				
				//Execute statement
				 
				$result = db2_execute($stmt);
				
				if (!$result) {
				    echo 'The db2 execute failed. ';
				    echo 'SQLSTATE value: ' . db2_stmt_error();
				    echo ' Message: ' .   db2_stmt_errormsg();
				    echo '<br>' . $sql;
				}
				else
				{
				    $row = db2_fetch_array($stmt);
				    $dbtitle = $row[1];
				    $dblayout = $row[2];
				    $dbstylsht = $row[8];
				    $dbrfsec = $row[9];
				    $dbrfurl = $row[10];
				    $dblogo = $row[11];
				    
				}
    				//close connection
    				db2_close($i5link);
    				?>
				
				
				<form method="post">
				<table class="table-noline">
				<tr>
				<td>
				<label for="dbtitle">Dashboard Title</label>
				</td>
				<td>
				<input id="dbtitle" name="dbtitle" value="<?php echo trim($dbtitle)?>" />
				</td>
				</tr>
				
				<tr>
				<td>
				<label for="dblayout">Dashboard Layout</label>
				</td>
				<td>
				<input list="dblayout" name="dblayout" value="<?php echo trim($dblayout)?>" />
				<datalist id="dblayout">
				  <option value="DBWHS001">
				  <option value="DBWHS002">
				  <option value="DBWHS003">
				  <option value="DBFBLOOK">
				  <option value="DBBSD001">
				</datalist>
				</td>
				</tr>
				
				<tr>
				<td>
				<label for="dbstlsht">Dashboard Style Sheet</label>
				</td>
				<td>
				<input id="dbstylsht" name="dbstylsht" value="<?php echo trim($dbstylsht)?>" />
				</td>
				</tr>
				
				<tr>
				<td>
				<label for="dbrfsec">Dashboard Refresh Rate(sec)</label>
				</td>
				<td>
				<input id="dbrfsec" name="dbrfsec" value="<?php echo $dbrfsec?>" />
				</td>
				</tr> 
				
				<tr>
				<td>
				<label for="dbrfurl">Dashboard Refresh URL</label>
				</td>
				<td>
				<input id="dbrfurl" name="dbrfurl" value="<?php echo trim($dbrfurl)?>" />
				</td>
				</tr>
				
				<tr>
				<td>
				<label for="dbrfurl">Dashboard Logo</label>
				</td>
				<td>
				<input id="dblogo" name="dblogo" value="<?php echo trim($dblogo)?>" />
				</td>
				</tr> 
				
	            <tr>
	            <td>
				<input type="submit" value="Update" class="button"/>
				<a href="http:maintdbsecurity.php?DB=<?php echo $dbname ?>" class="button">Security</a>
				</td>
				</tr>  
				  </table>
				</form>
						    
                
			
		</div>
		
		<div class="footer">
			Powered by: ScoreStory		
		</div>

	</div>
	
</body>
</html>
